import {
  MODULE_META,
  SCORE_MODULES,
  SESSION_MODULES,
  OUTCOMES,
  OUTCOME_KEYS,
  PRIORITY_MODULES,
  PLAN_PHASES,
  buildPlan,
  getCurrentWeek,
  getFocusTasks,
  isTaskDone,
  calculateOverallBand,
  getStats,
  getRecommendedAction,
  parseBackup,
  createBackup,
  backupSummary,
  mergeStates,
  createDefaultState,
  normalizeSettings,
  formatISODate,
  formatMonthDay,
  formatShortDate,
  formatWeekday,
  formatDuration,
  formatBand,
  parseISODate,
  toLocalDate,
  addDays,
  dateDiffDays
} from './core.js';
import {
  loadState,
  saveState,
  clearState,
  readSaveMeta,
  markExportedAt
} from './storage.js';
import { icon, moduleIcon } from './icons.js';
import {
  VOCAB_RATINGS,
  LISTENING_DRILLS,
  SPEAKING_PROMPTS,
  getVocabularyCards,
  getVocabularyCard,
  getNextVocabularyCard,
  reviewVocabularyCard,
  compareDictation,
  getListeningStats,
  getNextListeningDrill,
  getSpeakingPrompt,
  getNextSpeakingPrompt,
  getSpeakingStats,
  getPracticeStats,
  formatClock
} from './training.js';

const TABS = [
  { id: 'today', label: '今日', icon: 'target' },
  { id: 'plan', label: '计划', icon: 'calendar' },
  { id: 'practice', label: '练习', icon: 'layers' },
  { id: 'log', label: '记录', icon: 'archive' },
  { id: 'mock', label: '模考', icon: 'check' },
  { id: 'settings', label: '设置', icon: 'sliders' }
];
const TAB_IDS = new Set(TABS.map((tab) => tab.id));
const MODULE_ICONS = {
  listening: 'headphones',
  speaking: 'microphone',
  reading: 'book',
  writing: 'pen',
  review: 'rotate'
};
const PRIORITY_COPY = {
  listening: '先做一次 Section 3 精听，记录漏听词、同义替换与注意力断点。',
  speaking: '完成一题 Part 2 录音，只记录卡顿位置、重复表达和一个重录动作。',
  reading: '限时完成一组题，为每道错题标注原文证据句，不把错误归因于“粗心”。',
  writing: '先列结构再限时成稿，只做一轮针对任务回应的修改。'
};
const PRIORITY_ABBR = {
  listening: '听',
  speaking: '说',
  reading: '读',
  writing: '写'
};

function priorityModules() {
  return ['listening', 'speaking', 'reading', 'writing'].filter((module) => state.settings.priorities.includes(module));
}

function priorityPhrase() {
  const selected = priorityModules();
  if (selected.length === 4) return '四项均衡';
  if (selected.length === 1) return `${MODULE_META[selected[0]].label}优先`;
  return `${selected.map((module) => PRIORITY_ABBR[module]).join('')}优先`;
}

function priorityModuleNames() {
  return priorityModules().map((module) => MODULE_META[module].label).join('、');
}

const OUTCOME_LABELS = OUTCOMES;
const CONFIDENCE_LABELS = {
  1: '很低 / 明显失控',
  2: '偏低 / 多处卡住',
  3: '一般 / 完成但有缺口',
  4: '较稳 / 少量问题',
  5: '稳定 / 可复现'
};
const CONFIDENCE_SHORT = {
  1: '很低',
  2: '偏低',
  3: '一般',
  4: '较稳',
  5: '稳定'
};

const bootResult = loadState();
let state = bootResult.state;
let plan = buildPlan(state.settings);
let activeTab = tabFromHash();
let activeTaskId = null;
let openWeekNumber = null;
let editingSessionId = null;
let editingMockId = null;
let recordModule = 'all';
let recordDays = 'all';
let pendingImport = null;
let dialogKind = null;
let saveError = null;
let storageWarning = bootResult.error;
let toastTimer = null;
let toastAction = null;

let practiceMode = 'vocabulary';
let vocabularyCardId = null;
let vocabularyRevealed = false;
let listeningDrillId = null;
let listeningStartedAt = null;
let dictationChecked = false;
let dictationResult = null;
let dictationAnswer = '';
let speakingPart = 2;
let speakingPromptId = 'p2-01';
let speakingPhase = 'idle';
let speakingRemaining = 0;
let speakingTotal = 0;
let speakingDeadline = 0;
let speakingTimer = null;
let speakingPrepStartedAt = null;
let speakingAnswerStartedAt = null;
let speakingPrepUsed = 0;
let speakingDurationSec = 0;
let speakingStarting = false;
let speakingStatusNote = '';
let mediaStream = null;
let mediaRecorder = null;
let recordingChunks = [];
let recordedUrl = '';
let recordingState = 'idle';
let speakingRunToken = 0;

const appRoot = document.getElementById('app');
let toastRoot = null;
let dialogRoot = null;

const escapeHTML = (value) => String(value ?? '').replace(/[&<>"']/g, (character) => ({
  '&': '&amp;',
  '<': '&lt;',
  '>': '&gt;',
  '"': '&quot;',
  "'": '&#39;'
}[character]));

const escapeAttr = escapeHTML;

function tabFromHash() {
  const candidate = window.location.hash.replace(/^#/, '');
  return TAB_IDS.has(candidate) ? candidate : 'today';
}

function setHash(tab) {
  const next = `#${tab}`;
  if (window.location.hash !== next) window.history.replaceState(null, '', next);
}

function formatFullDate(value) {
  const date = toLocalDate(value);
  if (!date) return '—';
  return new Intl.DateTimeFormat('zh-CN', { year: 'numeric', month: 'long', day: 'numeric' }).format(date);
}

function formatDateTime(value) {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return '—';
  return new Intl.DateTimeFormat('zh-CN', {
    month: 'numeric',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  }).format(date);
}

function formatTime(value) {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return '—';
  return new Intl.DateTimeFormat('zh-CN', { hour: '2-digit', minute: '2-digit' }).format(date);
}

function plural(value, singular, pluralValue = `${value}`) {
  return Number(value) === 1 ? singular : pluralValue;
}

function makeId(prefix) {
  if (globalThis.crypto && typeof globalThis.crypto.randomUUID === 'function') {
    return `${prefix}-${globalThis.crypto.randomUUID()}`;
  }
  return `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
}

function todayISO() {
  return formatISODate(new Date());
}

function allTasks() {
  return plan.flatMap((week) => week.tasks);
}

function findTask(taskId) {
  return allTasks().find((task) => task.id === taskId) || null;
}

function weekEvidenceCount(week) {
  return week.tasks.filter((task) => isTaskDone(state, task.id)).length;
}

function weekHasSessions(week) {
  return state.sessions.some((session) => session.date >= week.startDate && session.date <= week.endDate);
}

function weekHasEvidence(week) {
  return weekEvidenceCount(week) > 0 || weekHasSessions(week);
}

function currentPlanWeek() {
  return getCurrentWeek(plan, new Date());
}

function currentDayNumber() {
  if (!plan.length) return 0;
  return (dateDiffDays(plan[0].startDate, todayISO()) ?? 0) + 1;
}

function planDayLabel() {
  const day = currentDayNumber();
  const total = plan.length * 7;
  if (day < 1) return `START IN ${Math.abs(day - 1)}D`;
  if (day > total) return 'PLAN COMPLETE';
  return `DAY ${String(day).padStart(2, '0')} / ${total}`;
}

function ensureOverlays() {
  if (!toastRoot) {
    toastRoot = document.createElement('div');
    toastRoot.className = 'toast-region';
    toastRoot.setAttribute('role', 'status');
    toastRoot.setAttribute('aria-live', 'polite');
    toastRoot.setAttribute('aria-atomic', 'false');
    document.body.appendChild(toastRoot);
    toastRoot.addEventListener('click', (event) => {
      const action = event.target.closest('[data-toast-action]');
      if (action) {
        const callback = toastAction;
        clearToast();
        if (callback) callback();
        return;
      }
      if (event.target.closest('[data-toast-close]')) clearToast();
    });
  }
  if (!dialogRoot) {
    dialogRoot = document.createElement('div');
    dialogRoot.id = 'dialog-root';
    document.body.appendChild(dialogRoot);
  }
}

function tabLabel(tab) {
  return tab.id === 'plan' ? `${plan.length} 周计划` : tab.label;
}

function updateTitle() {
  const tab = TABS.find((item) => item.id === activeTab);
  const label = tab ? tabLabel(tab) : '训练台';
  document.title = `${label} · IELTS 训练台 8.0`;
}

function saveMarkup() {
  let className = 'save-state';
  let label = '本机自动保存';
  let mobileLabel = '本机保存';
  if (saveError) {
    className += ' has-error';
    label = '保存失败';
    mobileLabel = '保存失败';
  } else {
    const meta = readSaveMeta();
    if (meta?.lastSavedAt) {
      label = `已保存 ${formatTime(meta.lastSavedAt)}`;
      mobileLabel = `${formatTime(meta.lastSavedAt)} 已存`;
    }
  }
  return `<span class="${className}" role="status" aria-live="polite"><i class="save-dot" aria-hidden="true"></i><span class="save-label">${escapeHTML(label)}</span><span class="save-label-mobile" aria-hidden="true">${escapeHTML(mobileLabel)}</span></span>`;
}

function updateSaveIndicator() {
  const current = document.querySelector('.save-state');
  if (!current) return;
  const wrapper = document.createElement('div');
  wrapper.innerHTML = saveMarkup();
  current.replaceWith(wrapper.firstElementChild);
}

function persist() {
  state.updatedAt = new Date().toISOString();
  const result = saveState(state);
  if (result.ok) {
    saveError = null;
    if (bootResult.source !== 'memory') storageWarning = null;
  } else {
    saveError = result.error;
  }
  updateSaveIndicator();
  return result.ok;
}

function render({ scrollMode = 'preserve', focusSelector = null } = {}) {
  ensureOverlays();
  const previousScroll = window.scrollY;
  appRoot.innerHTML = renderApp();
  if (activeTab === 'practice') updateSpeakingTimerUI();
  updateTitle();
  if (scrollMode === 'top') {
    window.scrollTo({ top: 0, behavior: 'auto' });
  } else {
    requestAnimationFrame(() => window.scrollTo({ top: previousScroll, behavior: 'auto' }));
  }
  if (focusSelector) {
    requestAnimationFrame(() => {
      const target = document.querySelector(focusSelector);
      if (!target) return;
      target.scrollIntoView({ block: 'center', behavior: 'smooth' });
      const focusable = target.querySelector('input:not([type="hidden"]), select, textarea, button');
      focusable?.focus({ preventScroll: true });
    });
  }
}

function renderApp() {
  const week = currentPlanWeek();
  return `
    <div class="app">
      ${renderMarginRail(week)}
      <div class="console">
        ${renderTopbar()}
        ${renderRouteBand(week)}
        <main id="main" class="main-region" tabindex="-1">
          ${renderNotices()}
          ${renderView()}
        </main>
        ${renderMobileNav()}
      </div>
    </div>
  `;
}

function renderNotices() {
  const notices = [];
  if (storageWarning) {
    notices.push(`
      <div class="notice is-warning" role="status">
        ${icon('warning', 16)}
        <div class="notice-copy">
          <strong>本机保存需要注意</strong>${escapeHTML(storageWarning)}
          ${bootResult.recoveryRaw ? '<button class="text-button" type="button" data-action="export-recovery" style="margin-top:6px">下载原始恢复副本</button>' : ''}
        </div>
      </div>
    `);
  }
  if (saveError) {
    notices.push(`
      <div class="notice is-error" role="alert">
        ${icon('warning', 16)}
        <div class="notice-copy"><strong>最新改动未写入本机</strong>${escapeHTML(saveError)} 请先导出 JSON，避免关闭页面后丢失。</div>
      </div>
    `);
  }
  return notices.join('');
}

function renderTopbar() {
  return `
    <header class="topbar">
      <div class="identity">
        <span class="seal" aria-hidden="true">雅</span>
        <div class="identity-copy">
          <strong>雅思训练台</strong>
          <small>A 类 · 目标 ${formatBand(state.settings.targetBand)}</small>
        </div>
      </div>
      <nav class="nav-desktop" aria-label="主导航">
        ${TABS.map((tab) => `
          <button class="nav-tab" type="button" data-action="tab" data-tab="${tab.id}" ${activeTab === tab.id ? 'aria-current="page"' : ''}>${tabLabel(tab)}</button>
        `).join('')}
      </nav>
      <div class="top-actions">
        ${saveMarkup()}
        <button class="btn" type="button" data-action="import" aria-label="导入 JSON 进度">
          ${icon('upload', 15)}<span class="btn-label">导入</span>
        </button>
        <button class="btn btn-primary" type="button" data-action="export" aria-label="导出 JSON 进度">
          ${icon('download', 15)}<span class="btn-label">导出 JSON</span>
        </button>
      </div>
    </header>
  `;
}

function renderMarginRail(week) {
  return `
    <aside class="margin-rail" aria-label="${plan.length} 周训练刻度与页边批注">
      <div class="rail-mark">
        <span class="seal" aria-hidden="true">雅</span>
        <small>IELTS<br>A 类训练</small>
      </div>
      <div class="rail-axis">
        <ol class="rail-ticks" aria-label="训练周刻度">
          ${plan.map((item) => {
            const done = weekEvidenceCount(item);
            const className = [
              'rail-tick',
              item.number === week?.number ? 'is-current' : '',
              done === item.tasks.length ? 'is-done' : ''
            ].filter(Boolean).join(' ');
            return `<li><button class="${className}" type="button" data-action="open-week" data-week="${item.number}" ${item.number === week?.number ? 'aria-current="step"' : ''} title="第 ${item.number} 周：${escapeAttr(item.focus)}">${String(item.number).padStart(2, '0')}</button></li>`;
          }).join('')}
        </ol>
        <div class="rail-phases" aria-hidden="true">
          ${PLAN_PHASES.map((phase) => `<span>${escapeHTML(phase.short)}</span>`).join('')}
        </div>
      </div>
      <div class="rail-foot"><span>${plan.length}W ROUTE</span><b>${plan.length}</b></div>
    </aside>
  `;
}

function renderMobileNav() {
  return `
    <nav class="mobile-nav" aria-label="移动端主导航">
      ${TABS.map((tab) => `
        <button class="mobile-tab" type="button" data-action="tab" data-tab="${tab.id}" ${activeTab === tab.id ? 'aria-current="page"' : ''}>
          ${icon(tab.icon, 18)}
          <span>${tab.id === 'plan' ? `${plan.length} 周` : tab.label}</span>
        </button>
      `).join('')}
    </nav>
  `;
}

function renderRouteBand(week) {
  const doneTasks = plan.reduce((sum, item) => sum + weekEvidenceCount(item), 0);
  const totalTasks = plan.length * 6;
  const activeWeeks = plan.filter(weekHasEvidence).length;
  const phase = week?.phase || plan[0]?.phase;
  const planLabel = state.settings.examDate
    ? `${formatFullDate(state.settings.examDate)} 考试`
    : '考试日未设置';
  return `
    <section class="route-band" aria-labelledby="route-title">
      <div class="route-head">
        <div class="route-title">
          <h1 id="route-title">${plan.length} 周训练路线 · ${escapeHTML(phase?.label || '建立可测基线')}</h1>
          <p>${escapeHTML(planLabel)} · ${formatShortDate(state.settings.planStart)}—${formatShortDate(plan.at(-1)?.endDate)} · 每周 ${state.settings.weeklyHours} 小时 · ${priorityPhrase()}</p>
        </div>
        <div class="route-meta">
          <span><b>${activeWeeks}</b> / ${plan.length} 周有证据</span>
          <span><b>${doneTasks}</b> / ${totalTasks} 次已完成</span>
          <span class="route-key" aria-hidden="true"><i class="is-current"></i>当前周 <i class="is-priority"></i>优先 <i class="is-done"></i>已完成</span>
          <button class="text-button" type="button" data-action="tab" data-tab="settings">调整计划</button>
        </div>
      </div>
      <div class="week-strip-scroll">
        <ol class="week-strip" aria-label="${plan.length} 周训练路线">
          ${plan.map((item) => {
            const done = weekEvidenceCount(item);
            return `
              <li>
                <button class="week-cell ${item.number === week?.number ? 'is-current' : ''} ${weekHasEvidence(item) ? 'has-evidence' : ''}" type="button" data-action="open-week" data-week="${item.number}" aria-label="第 ${item.number} 周，${escapeAttr(item.focus)}，完成 ${done} / ${item.tasks.length} 次${item.number === week?.number ? '，当前周' : ''}" ${item.number === week?.number ? 'aria-current="date"' : ''}>
                  <span class="week-number">W${String(item.number).padStart(2, '0')}</span>
                  <span class="week-marks" aria-hidden="true">${item.tasks.map((task) => `<i class="${isTaskDone(state, task.id) ? 'is-done' : ''}"></i>`).join('')}</span>
                </button>
              </li>
            `;
          }).join('')}
        </ol>
      </div>
    </section>
  `;
}

function renderView() {
  if (activeTab === 'plan') return renderPlanView();
  if (activeTab === 'practice') return renderPracticeView();
  if (activeTab === 'log') return renderLogView();
  if (activeTab === 'mock') return renderMockView();
  if (activeTab === 'settings') return renderSettingsView();
  return renderTodayView();
}

function moduleLabel(module, short = false) {
  const meta = MODULE_META[module] || MODULE_META.review;
  return `<span class="module-label is-${module}">${moduleIcon(module, 13)}${short ? meta.label : `${meta.label} · ${meta.english}`}</span>`;
}

function statusLabel(status) {
  return {
    today: '今日',
    overdue: '逾期',
    next: '下一个',
    later: '待排'
  }[status] || '待办';
}

function renderTaskRow(task) {
  const done = isTaskDone(state, task.id);
  return `
    <article class="task-row ${done ? 'is-done' : ''}">
      <input class="task-check" type="checkbox" data-action="toggle-task" data-task-id="${escapeAttr(task.id)}" ${done ? 'checked' : ''} aria-label="${done ? '取消完成' : '标记完成'}：${escapeAttr(task.title)}">
      <div class="task-main">
        <div class="task-kicker">
          ${moduleLabel(task.module)}
          ${task.priority ? '<span class="mini-mark is-priority">优先</span>' : '<span class="mini-mark">补充</span>'}
          <span class="mini-mark ${task.displayStatus === 'overdue' ? 'is-overdue' : ''}">${statusLabel(task.displayStatus)}</span>
        </div>
        <h3 class="task-title">${escapeHTML(task.title)}</h3>
        <p class="task-prompt">${escapeHTML(task.prompt)}</p>
      </div>
      <div class="task-end">
        <span class="task-minutes">${task.minutes} MIN · ${formatShortDate(task.scheduledDate)}</span>
        <button class="task-start" type="button" data-action="start-task" data-task-id="${escapeAttr(task.id)}">${activeTaskId === task.id ? '收起' : done ? '补记' : '开始'}</button>
      </div>
    </article>
  `;
}

function renderTodayView() {
  const stats = getStats(state, plan, new Date());
  const week = stats.currentWeek;
  const focus = getFocusTasks(state, plan, new Date());
  const currentWeekRecord = currentPlanWeek();
  const activeTask = activeTaskId ? findTask(activeTaskId) : null;
  const recommended = getRecommendedAction(state, plan, new Date());
  const totalFocusMinutes = focus.reduce((sum, task) => sum + task.minutes, 0);
  const dayLabel = planDayLabel();
  const weekDone = currentWeekRecord ? weekEvidenceCount(currentWeekRecord) : 0;
  const weekTotal = currentWeekRecord?.tasks.length || 0;

  return `
    <section class="view" aria-labelledby="today-heading">
      <div class="today-layout">
        <div class="today-main">
          <header class="view-head today-head">
            <div>
              <div class="today-title-row">
                <h2 id="today-heading">今日训练</h2>
                <span class="today-tag">${escapeHTML(dayLabel)}</span>
              </div>
              <p>${focus.length ? `先完成${priorityPhrase()}训练块，再用其余模块补证据。没有记录，就不生成推测分数。` : `本周计划已经清空或尚未展开。进入 ${plan.length} 周计划检查下一项，或直接记录一次自主训练。`}</p>
            </div>
            <div class="view-count"><b>${weekDone}</b><span>/ ${weekTotal} 本周完成 · ${totalFocusMinutes} MIN 优先动作</span></div>
          </header>

          <button class="today-next" type="button" data-action="${recommended?.id ? 'start-task' : 'tab'}" ${recommended?.id ? `data-task-id="${escapeAttr(recommended.id)}"` : 'data-tab="plan"'}>
            <span><b>下一步</b>${escapeHTML(recommended?.title || `进入 ${plan.length} 周计划，检查下一项训练`)}</span>
            <b>${recommended?.id ? '开始' : '查看'} ${icon('arrowRight', 11)}</b>
          </button>

          <div class="today-workbench">
            <div class="today-sequence-col">
              <section class="sequence" aria-label="今日优先训练">
            ${focus.length ? focus.map(renderTaskRow).join('') : `
              <div class="empty-state">
                <span class="empty-glyph">${icon('check', 20)}</span>
                <h3>本周已没有待办任务</h3>
                <p>这不是“高分证明”，只是计划完成。请用一次完整模考或一次针对性复盘来更新证据。</p>
                <button class="btn" type="button" data-action="tab" data-tab="mock">录入模考</button>
              </div>
              `}
              </section>

              ${activeTask ? renderTaskRunner(activeTask) : ''}

              <div class="output-brief">
                <div><span>本次输出</span><p>一条可追溯的训练记录：做了什么、用了多久、缺口的证据是什么。</p></div>
                <div><span>完成标准</span><p>说得清下一次的修正动作，而不只是“做完了”或“对了答案”。</p></div>
              </div>
            </div>

            <section class="capture-panel" aria-labelledby="quick-capture-title">
              <div class="capture-head">
                <div>
                  <h3 id="quick-capture-title">3 分钟记录</h3>
                  <p>手机快速打卡，电脑复盘趋势。提交后立即写入本机。</p>
                </div>
                <button class="text-button" type="button" data-action="tab" data-tab="log">查看全部记录</button>
              </div>
              ${renderSessionForm({ prefix: 'quick', compact: true })}
            </section>
          </div>
        </div>
        ${renderEvidenceRail(stats, recommended)}
      </div>
      ${renderDayEvidence(stats)}
    </section>
  `;
}

function renderPracticeView() {
  const stats = getPracticeStats(state, new Date());
  const modeCopy = {
    vocabulary: `${stats.vocab.due} 张到期 · ${stats.vocab.fresh} 张新卡`,
    listening: stats.listening.accuracy === null ? '尚无听写样本' : `听写吻合 ${stats.listening.accuracy}%`,
    speaking: `${stats.speaking.total} 次口试 · ${formatClock(stats.speaking.seconds)} 已作答`
  };
  return `
    <section class="view practice-view" aria-labelledby="practice-heading">
      <header class="view-head practice-head">
        <div>
          <h2 id="practice-heading">练习台</h2>
          <p>单词、听写、口语在同一张训练台上完成。练习结果写入本机并随 JSON 备份；麦克风录音只留在当前页面。</p>
        </div>
        <div class="view-count"><b>${stats.todayActions}</b><span>今日练习动作 · ${escapeHTML(modeCopy[practiceMode])}</span></div>
      </header>

      <nav class="practice-switch" aria-label="选择练习类型">
        ${renderPracticeModeButton('vocabulary', 'book', '单词', '间隔复习', `${stats.vocab.due} DUE`)}
        ${renderPracticeModeButton('listening', 'headphones', '听力', '盲听听写', `${stats.listening.today} TODAY`)}
        ${renderPracticeModeButton('speaking', 'microphone', '口语', '计时录答', `${stats.speaking.today} TAKE`)}
      </nav>

      <div class="practice-layout">
        <div class="practice-main">
          ${practiceMode === 'listening'
            ? renderListeningWorkspace()
            : practiceMode === 'speaking'
              ? renderSpeakingWorkspace()
              : renderVocabularyWorkspace(stats)}
        </div>
        ${renderPracticeMargin(stats)}
      </div>
    </section>
  `;
}

function renderPracticeModeButton(mode, iconName, label, copy, badge) {
  const active = practiceMode === mode;
  return `
    <button class="practice-mode" type="button" data-action="practice-mode" data-mode="${mode}" aria-pressed="${active}">
      ${icon(iconName, 17)}
      <span><b>${label}</b><small>${copy}</small></span>
      <em>${badge}</em>
    </button>
  `;
}

function renderVocabularyWorkspace(stats) {
  const card = vocabularyCardId ? getVocabularyCard(state, vocabularyCardId) : getNextVocabularyCard(state, new Date());
  const progress = card ? state.vocabulary.progress[card.id] : null;
  const waitingOnly = !card && stats.vocab.total > 0;
  return `
    <section class="practice-stage word-stage" aria-labelledby="vocabulary-title">
      <header class="practice-stage-head">
        <div>
          <h3 id="vocabulary-title">到期复习</h3>
          <p>先说出释义和搭配，再显示答案。自评决定下一次出现时间，不按点击次数计算掌握度。</p>
        </div>
        <div class="stage-counter"><b>${stats.vocab.due + stats.vocab.fresh}</b><span>张待练 · ${stats.vocab.mature} 张已进入长间隔</span></div>
      </header>

      ${card ? `
        <article class="word-sheet" aria-labelledby="word-term">
          <div class="word-meta">
            <span>${card.custom ? '自建词条' : 'ACADEMIC CORE'} · ${escapeHTML(card.part)}</span>
            <span>${progress ? `已复习 ${progress.reps} 次 · 当前间隔 ${progress.intervalDays} 天` : '首次出现 · 建立记忆锚点'}</span>
          </div>
          <div class="word-face">
            <h3 class="word-term" id="word-term" lang="en">${escapeHTML(card.term)}</h3>
            ${card.phonetic ? `<p class="word-phonetic">${escapeHTML(card.phonetic)}</p>` : ''}
            ${!vocabularyRevealed ? `
              <p class="word-recall">先回忆：中文释义、常见搭配，以及一个能说服考官的例句。</p>
              <button class="btn btn-primary word-reveal" type="button" data-action="vocab-reveal">显示答案</button>
            ` : `
              <div class="word-answer" id="word-answer">
                <p class="word-meaning">${escapeHTML(card.meaning || '尚未填写释义')}</p>
                ${card.collocation ? `<p class="word-collocation"><span>搭配</span>${escapeHTML(card.collocation)}</p>` : ''}
                ${card.example ? `<blockquote class="word-example" lang="en">${escapeHTML(card.example)}</blockquote>` : ''}
                ${card.translation ? `<p class="word-translation">${escapeHTML(card.translation)}</p>` : ''}
              </div>
              <div class="word-rating" aria-label="评估这个单词的掌握程度">
                ${Object.entries(VOCAB_RATINGS).map(([rating, meta]) => `
                  <button type="button" data-action="rate-vocabulary" data-rating="${rating}" data-card-id="${escapeAttr(card.id)}">
                    <b>${meta.label}</b><small>${meta.hint}</small>
                  </button>
                `).join('')}
              </div>
            `}
          </div>
          <footer class="word-foot">
            <span>${progress?.lastReviewedAt ? `上次复习 ${formatDateTime(progress.lastReviewedAt)}` : '还没留下复习记录'}</span>
            <span>${progress?.dueAt ? `下次到期 ${formatDateTime(progress.dueAt)}` : '本轮结束后进入间隔队列'}</span>
          </footer>
        </article>
      ` : `
        <div class="practice-empty">
          <span>${icon(waitingOnly ? 'clock' : 'check', 20)}</span>
          <h3>${waitingOnly ? '到期队列已清空' : '词库尚未展开'}</h3>
          <p>${waitingOnly
            ? `下一张卡将在 ${stats.vocab.nextDueAt ? formatDateTime(stats.vocab.nextDueAt) : '稍后'} 到期。也可以提前复习最早到期的一张。`
            : '导入的词库进度不可用，或自建词条尚未生成。请刷新页面后重试。'}</p>
          ${waitingOnly ? '<button class="btn" type="button" data-action="vocabulary-early">提前复习一张</button>' : ''}
        </div>
      `}
    </section>
  `;
}

function currentListeningDrill() {
  let drill = LISTENING_DRILLS.find((item) => item.id === listeningDrillId) || null;
  if (!drill) {
    drill = getNextListeningDrill(state, new Date());
    listeningDrillId = drill?.id || null;
    listeningStartedAt = Date.now();
    dictationChecked = false;
    dictationResult = null;
    dictationAnswer = '';
  }
  return drill;
}

function renderListeningWorkspace() {
  const drill = currentListeningDrill();
  if (!drill) return '<div class="practice-empty"><h3>听写题组为空</h3><p>请刷新页面重新载入训练内容。</p></div>';
  const attempts = state.listeningAttempts.filter((attempt) => attempt.drillId === drill.id);
  const correctCount = attempts.filter((attempt) => attempt.correct).length;
  return `
    <section class="practice-stage listening-stage" aria-labelledby="listening-title">
      <header class="practice-stage-head">
        <div>
          <h3 id="listening-title">盲听听写</h3>
          <p>系统语音朗读原创短句。先完整听一遍，再逐词写下；核对后只盯住漏写与拼写，不重听十遍求安慰。</p>
        </div>
        <div class="stage-actions">
          <span class="stage-counter"><b>${correctCount}</b><span>/ ${attempts.length} 次逐词一致</span></span>
          <button class="btn btn-small" type="button" data-action="next-drill">换一题</button>
        </div>
      </header>

      <div class="dictation-stage">
        <section class="listen-source" aria-label="听写播放控制">
          <div class="listen-meta"><span>${drill.section}</span><span>${escapeHTML(drill.focus)}</span></div>
          <div class="listen-wave" data-listen-wave aria-hidden="true">
            ${Array.from({ length: 14 }, (_, index) => `<i style="--wave:${(index % 5) + 2}"></i>`).join('')}
          </div>
          <p class="listen-instruction">只播放句子的英文音频。播放前不要展开原文；如果第一遍没听清，先用慢速补齐连读。</p>
          <div class="listen-controls">
            <button class="btn btn-primary" type="button" data-action="listen-play">${icon('headphones', 15)}播放</button>
            <button class="btn" type="button" data-action="listen-slow">慢速 0.72×</button>
          </div>
          <p class="listen-status" data-listening-status aria-live="polite">${'speechSynthesis' in window ? '等待播放 · 使用系统英文语音' : '当前浏览器没有语音合成；可换用 Safari 或 Chrome'}</p>
        </section>

        <form class="dictation-form" data-form="dictation">
          <div class="field">
            <label for="dictation-answer">写下你听到的完整句子</label>
            <textarea class="textarea" id="dictation-answer" name="answer" rows="4" maxlength="2000" autocomplete="off" autocapitalize="none" spellcheck="false" required placeholder="Don’t correct from memory after the sentence ends.">${escapeHTML(dictationAnswer)}</textarea>
            <span class="field-hint">大小写、句号与逗号不扣分；单复数、冠词和词序会进入比对。</span>
          </div>
          ${dictationChecked && dictationResult ? renderDictationResult(dictationResult, drill) : ''}
          <div class="form-actions">
            <span class="form-hint">${dictationChecked ? '确认答案后保存，记录才进入正确率。' : '首次核对会显示原文与词级差异。'}</span>
            <button class="btn" type="submit" name="intent" value="check">${dictationChecked ? '重新核对' : '核对听写'}</button>
            ${dictationChecked ? '<button class="btn btn-primary" type="submit" name="intent" value="save">保存并换题</button>' : ''}
          </div>
        </form>
      </div>
    </section>
  `;
}

function renderDictationResult(result, drill) {
  const missing = result.missing.slice(0, 10).join(' · ');
  const extra = result.extra.slice(0, 10).join(' · ');
  return `
    <section class="dictation-result ${result.isCorrect ? 'is-correct' : ''}" aria-labelledby="dictation-result-title" tabindex="-1">
      <div class="dictation-result-head">
        <div>
          <span class="result-mark">${result.isCorrect ? '逐词一致' : '有差异'}</span>
          <h4 id="dictation-result-title">${result.isCorrect ? '这句听清了' : `词级吻合 ${result.accuracy}%`}</h4>
        </div>
        <b>${result.matched}<span> / ${result.normalizedExpected.split(' ').filter(Boolean).length} 词</span></b>
      </div>
      <p class="dictation-original" lang="en"><span>原文</span>${escapeHTML(drill.sentence)}</p>
      <div class="dictation-diff-grid">
        <p><span>漏写 / 错序</span>${missing ? escapeHTML(missing) : '无'}</p>
        <p><span>多写</span>${extra ? escapeHTML(extra) : '无'}</p>
      </div>
      <div class="dictation-save">
        <label class="field">
          <span class="field-label">本次把握度</span>
          <select class="select" name="rating" aria-label="本次听写把握度">
            ${[1, 2, 3, 4, 5].map((value) => `<option value="${value}" ${value === (result.isCorrect ? 4 : 3) ? 'selected' : ''}>${value} / 5 · ${CONFIDENCE_SHORT[value]}</option>`).join('')}
          </select>
        </label>
      </div>
    </section>
  `;
}

function currentSpeakingPrompt() {
  let prompt = getSpeakingPrompt(speakingPromptId);
  if (!prompt || prompt.part !== speakingPart) {
    prompt = SPEAKING_PROMPTS.find((item) => item.part === speakingPart) || SPEAKING_PROMPTS[0];
    speakingPromptId = prompt.id;
  }
  return prompt;
}

function speakingStatusCopy(prompt) {
  if (speakingStatusNote) return speakingStatusNote;
  if (speakingPhase === 'prep') return '准备计时中。提纲只写关键词；倒计时结束后需手动开始作答。';
  if (speakingPhase === 'ready') return '准备结束。点击“开始作答”，麦克风会随作答计时启动。';
  if (speakingPhase === 'requesting') return '正在请求麦克风权限。拒绝权限仍可只计时并保存笔记。';
  if (speakingPhase === 'answer') return recordingState === 'recording' ? '正在作答并录音。保持自然语速，不要为了一次完美而重启。' : '正在作答；录音不可用，但计时与笔记仍会保留。';
  if (speakingPhase === 'processing') return '正在封装本页临时录音。';
  if (speakingPhase === 'done') return '作答结束。录音只存在本页，刷新即失效；保存只记录时长、自评和笔记。';
  return prompt.prepSec ? '先列出三个关键词，再开始计时。录音需要浏览器获得麦克风权限。' : '点击开始作答后会同时启动计时与录音。';
}

function renderSpeakingControls(prompt) {
  if (speakingPhase === 'requesting') {
    return `
      <button class="btn" type="button" data-action="speaking-skip-recording">跳过录音，直接作答</button>
      <button class="btn btn-quiet" type="button" data-action="speaking-reset">取消</button>
    `;
  }
  if (speakingPhase === 'processing') {
    return '<button class="btn btn-primary" type="button" disabled>处理录音…</button>';
  }
  if (speakingPhase === 'answer') {
    return `<button class="btn speaking-stop" type="button" data-action="speaking-stop">结束作答</button>`;
  }
  if (speakingPhase === 'done') {
    return `
      <button class="btn btn-primary" type="button" data-action="speaking-reset">重新作答</button>
      <button class="btn" type="button" data-action="next-speaking-prompt">换一题</button>
    `;
  }
  return `
    ${prompt.prepSec ? `<button class="btn ${speakingPhase === 'prep' ? 'btn-primary' : ''}" type="button" data-action="speaking-prep">${speakingPhase === 'prep' ? '重新开始准备' : `准备 ${prompt.prepSec}s`}</button>` : ''}
    <button class="btn ${speakingPhase === 'idle' && !prompt.prepSec ? 'btn-primary' : ''}" type="button" data-action="speaking-answer">开始作答</button>
    ${speakingPhase !== 'idle' ? '<button class="btn btn-quiet" type="button" data-action="speaking-reset">取消</button>' : ''}
  `;
}

function renderSpeakingWorkspace() {
  const prompt = currentSpeakingPrompt();
  const stats = getSpeakingStats(state, todayISO());
  const timerValue = speakingPhase === 'idle' ? (prompt.prepSec || prompt.speakSec) : speakingRemaining;
  const timerTotal = speakingPhase === 'idle' ? (prompt.prepSec || prompt.speakSec) : speakingTotal;
  const timerPercent = timerTotal ? Math.max(0, Math.min(100, (speakingRemaining / timerTotal) * 100)) : 0;
  return `
    <section class="practice-stage speaking-stage" aria-labelledby="speaking-title">
      <header class="practice-stage-head">
        <div>
          <h3 id="speaking-title">题卡计时</h3>
          <p>按真实口试节奏准备与作答。题卡与提示均为自写训练材料；录音只供本页回放，不写入 JSON。</p>
        </div>
        <div class="part-filter" role="group" aria-label="选择口语部分">
          ${[1, 2, 3].map((part) => `<button type="button" data-action="choose-speaking-part" data-part="${part}" aria-pressed="${speakingPart === part}">P${part}</button>`).join('')}
        </div>
      </header>

      <div class="speaking-stage-grid">
        <article class="speaking-cue">
          <div class="speaking-cue-meta"><span>${prompt.label} · ${escapeHTML(prompt.title)}</span><span>${stats.total} TAKES</span></div>
          <h3>${escapeHTML(prompt.prompt)}</h3>
          <ul>${prompt.bullets.map((item) => `<li>${escapeHTML(item)}</li>`).join('')}</ul>
          <div class="cue-targets">
            <span>8.0 观察点</span>
            ${prompt.targets.map((item) => `<p>${escapeHTML(item)}</p>`).join('')}
          </div>
          <footer>PREP ${prompt.prepSec}s · SPEAK ${prompt.speakSec}s · NO MODEL ANSWER</footer>
        </article>

        <section class="speaking-recorder" aria-labelledby="recorder-title">
          <div class="recorder-head">
            <div>
              <h4 id="recorder-title">${speakingPhase === 'prep' ? '准备' : speakingPhase === 'answer' ? '作答' : speakingPhase === 'done' ? '回听与记录' : '计时器'}</h4>
              <span class="recording-flag ${recordingState === 'recording' ? 'is-live' : ''}" data-recording-flag><i></i>${recordingState === 'recording' ? 'REC' : recordingState === 'ready' ? 'AUDIO READY' : 'LOCAL ONLY'}</span>
            </div>
            <output class="speaking-clock" data-speaking-timer aria-label="剩余时间">${formatClock(timerValue)}</output>
          </div>
          <div class="speaking-clock-track" aria-hidden="true"><i data-speaking-fill style="width:${timerPercent}%"></i></div>
          <p class="speaking-status" data-speaking-status role="status" aria-live="polite">${escapeHTML(speakingStatusCopy(prompt))}</p>
          <div class="speaking-controls">${renderSpeakingControls(prompt)}</div>
          ${recordedUrl && speakingPhase === 'done' ? `
            <div class="take-playback">
              <audio controls preload="metadata" src="${escapeAttr(recordedUrl)}"></audio>
              <p>临时录音 · 刷新页面后消失 · 不进入备份</p>
            </div>
          ` : ''}
          <p class="recorder-note">${navigator.mediaDevices?.getUserMedia && 'MediaRecorder' in window ? '首次录音会请求麦克风权限。' : '此浏览器不支持录音；计时、自评与笔记仍可使用。'}</p>
        </section>
      </div>

      ${speakingPhase === 'done' ? `
        <form class="speaking-review" data-form="speaking-save">
          <div class="speaking-review-head">
            <div><h4>保存这次口试</h4><p>只保存时长、自评和复盘笔记。音频不会离开当前页面。</p></div>
            <span>${formatClock(speakingDurationSec)} ANSWER · ${formatClock(speakingPrepUsed)} PREP</span>
          </div>
          <div class="form-grid">
            <div class="field span-2">
              <label for="speaking-rating">自评</label>
              <select class="select" id="speaking-rating" name="rating" required>
                ${[1, 2, 3, 4, 5].map((value) => `<option value="${value}" ${value === 3 ? 'selected' : ''}>${value} / 5 · ${CONFIDENCE_LABELS[value]}</option>`).join('')}
              </select>
            </div>
            <div class="field span-10">
              <label for="speaking-notes">本轮回听证据</label>
              <textarea class="textarea" id="speaking-notes" name="notes" maxlength="10000" rows="3" placeholder="例：Part 2 中段重复了 important；第三问没答完整；下一次只改一个停顿点。"></textarea>
            </div>
          </div>
          <div class="form-actions">
            <span class="form-hint">保存后音频立即释放，练习元数据进入本机进度。</span>
            <button class="btn btn-primary" type="submit">保存本次口试</button>
          </div>
        </form>
      ` : ''}
    </section>
  `;
}

function recentPracticeEvidence() {
  const listening = (state.listeningAttempts || []).map((attempt) => {
    const drill = LISTENING_DRILLS.find((item) => item.id === attempt.drillId);
    return {
      createdAt: attempt.createdAt,
      mark: 'L',
      title: drill?.focus || '听写',
      detail: attempt.correct ? '逐词一致' : '有差异',
      tone: attempt.correct ? 'is-correct' : ''
    };
  });
  const speaking = (state.speakingTakes || []).map((take) => {
    const prompt = getSpeakingPrompt(take.promptId);
    return {
      createdAt: take.createdAt,
      mark: 'S',
      title: prompt ? `${prompt.label} · ${prompt.title}` : '口语题卡',
      detail: `${formatClock(take.durationSec)} · ${take.rating}/5`,
      tone: ''
    };
  });
  return [...listening, ...speaking]
    .sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt)))
    .slice(0, 3);
}

function renderPracticeMargin(stats) {
  const recent = recentPracticeEvidence();
  return `
    <aside class="practice-margin" aria-label="练习进度与题库索引">
      <section class="margin-section">
        <h3>今日刻度</h3>
        <dl class="practice-stat-grid">
          <div><dt>单词复习</dt><dd>${stats.vocab.reviewedToday}</dd></div>
          <div><dt>到期词卡</dt><dd>${stats.vocab.due}</dd></div>
          <div><dt>听写正确率</dt><dd>${stats.listening.accuracy === null ? '—' : `${stats.listening.accuracy}%`}</dd></div>
          <div><dt>口语作答</dt><dd>${formatClock(stats.speaking.seconds)}</dd></div>
        </dl>
      </section>

      ${practiceMode === 'vocabulary' ? renderVocabularyMargin(stats) : practiceMode === 'listening' ? renderListeningMargin(stats) : renderSpeakingMargin()}

      <section class="margin-section recent-evidence">
        <h3>最近练习证据</h3>
        ${recent.length ? `<ol>${recent.map((item) => `
          <li><b>${item.mark}</b><span>${escapeHTML(item.title)}<small>${escapeHTML(item.detail)}</small></span><time>${formatShortDate(item.createdAt.slice(0, 10))}</time></li>
        `).join('')}</ol>` : '<p class="margin-empty">还没有听写或口试记录。完成一次核对或作答后，这里会保留可回溯的证据。</p>'}
      </section>
    </aside>
  `;
}

function renderVocabularyMargin(stats) {
  const percent = stats.vocab.total ? Math.round((stats.vocab.reviewed / stats.vocab.total) * 100) : 0;
  return `
    <section class="margin-section">
      <div class="margin-section-head"><h3>词库进度</h3><b>${percent}%</b></div>
      <div class="margin-progress" aria-hidden="true"><i style="width:${percent}%"></i></div>
      <p class="margin-copy">${stats.vocab.reviewed} / ${stats.vocab.total} 张已进入复习队列；${stats.vocab.mature} 张间隔达到 7 天以上。</p>
      ${stats.vocab.nextDueAt ? `<p class="margin-foot">下一张到期 ${formatDateTime(stats.vocab.nextDueAt)}</p>` : ''}
      <details class="vocabulary-add">
        <summary>加入自建词条 <span>+</span></summary>
        <form data-form="vocabulary-custom">
          <div class="field"><label for="custom-term">单词 / 短语</label><input class="input" id="custom-term" name="term" maxlength="80" required autocomplete="off" spellcheck="false"></div>
          <div class="field"><label for="custom-meaning">中文释义</label><input class="input" id="custom-meaning" name="meaning" maxlength="240" required autocomplete="off"></div>
          <div class="field"><label for="custom-example">自写例句 <span class="field-hint">（可选）</span></label><textarea class="textarea" id="custom-example" name="example" maxlength="500" rows="2"></textarea></div>
          <button class="btn btn-small" type="submit">加入词库</button>
        </form>
      </details>
    </section>
  `;
}

function renderListeningMargin(stats) {
  return `
    <section class="margin-section">
      <div class="margin-section-head"><h3>听写题组</h3><b>${stats.listening.total}</b></div>
      <div class="drill-index" aria-label="听写题目索引">
        ${LISTENING_DRILLS.map((drill) => {
          const count = state.listeningAttempts.filter((attempt) => attempt.drillId === drill.id).length;
          const current = drill.id === listeningDrillId;
          return `<button type="button" class="${count ? 'has-evidence' : ''} ${current ? 'is-current' : ''}" data-action="choose-drill" data-drill-id="${drill.id}" aria-label="${drill.section} ${drill.focus}${count ? `，已练 ${count} 次` : ''}" ${current ? 'aria-current="true"' : ''}>${drill.id.slice(1)}</button>`;
        }).join('')}
      </div>
      <p class="margin-copy">20 句原创短句，覆盖数字、条件、转折、学术观点与同义替换。系统语音取决于设备已安装的英文声音。</p>
    </section>
  `;
}

function renderSpeakingMargin() {
  const prompts = SPEAKING_PROMPTS.filter((prompt) => prompt.part === speakingPart);
  return `
    <section class="margin-section">
      <div class="margin-section-head"><h3>P${speakingPart} 题卡</h3><b>${prompts.length}</b></div>
      <div class="prompt-index">
        ${prompts.map((prompt) => `<button type="button" data-action="choose-speaking-prompt" data-prompt-id="${prompt.id}" aria-pressed="${prompt.id === speakingPromptId}"><span>${escapeHTML(prompt.title)}</span><small>${prompt.prepSec}s + ${prompt.speakSec}s</small></button>`).join('')}
      </div>
      <p class="margin-copy">录音只保存在页面内存中，刷新或切换页面即释放。导出的 JSON 只包含题目、时长、自评与笔记。</p>
    </section>
  `;
}

function renderTaskRunner(task) {
  const done = isTaskDone(state, task.id);
  return `
    <section class="task-runner" id="task-runner" aria-labelledby="runner-title">
      <div class="runner-head">
        <div>
          <div class="task-kicker">
            ${moduleLabel(task.module)}
            <span class="mini-mark">W${String(task.weekNumber).padStart(2, '0')} · ${formatShortDate(task.scheduledDate)}</span>
            ${done ? '<span class="mini-mark is-priority">已完成</span>' : ''}
          </div>
          <h3 id="runner-title">${escapeHTML(task.title)}</h3>
          <p class="runner-prompt">${escapeHTML(task.prompt)}</p>
        </div>
        <button class="icon-button" type="button" data-action="close-task" aria-label="收起训练详情">${icon('close', 17)}</button>
      </div>
      <div class="runner-body">
        <div class="runner-checklist">
          <h4>训练步骤</h4>
          <ol>${task.checklist.map((item) => `<li>${escapeHTML(item)}</li>`).join('')}</ol>
        </div>
        <div class="runner-form">
          <h4>训练记录</h4>
          ${renderSessionForm({ prefix: 'runner', task, compact: true })}
        </div>
      </div>
    </section>
  `;
}

function renderSessionForm({ prefix, task = null, editing = null, compact = false }) {
  const dateValue = editing?.date || todayISO();
  const moduleValue = editing?.module || task?.module || 'listening';
  const activityValue = editing?.activity || task?.title || '';
  const minutesValue = editing?.minutes || task?.minutes || 30;
  const outcomeValue = editing?.outcome || 'completed';
  const confidenceValue = editing?.confidence || 3;
  const notesValue = editing?.notes || '';
  const isEditing = Boolean(editing);
  const title = isEditing ? '修改训练记录' : task ? '记录本次训练' : '快速保存一次训练';
  return `
    <form class="${compact ? 'capture-form' : ''}" data-form="session" data-prefix="${escapeAttr(prefix)}" data-editing="${isEditing ? 'true' : 'false'}">
      <input type="hidden" name="sessionId" value="${escapeAttr(editing?.id || '')}">
      <input type="hidden" name="taskId" value="${escapeAttr(task?.id || editing?.taskId || '')}">
      <div class="form-grid">
        <div class="field field-module span-3">
          <label for="${prefix}-module">模块</label>
          <select class="select" id="${prefix}-module" name="module" required>
            ${SESSION_MODULES.map((module) => `<option value="${module}" ${module === moduleValue ? 'selected' : ''}>${MODULE_META[module].label} · ${MODULE_META[module].english}</option>`).join('')}
          </select>
        </div>
        <div class="field field-date span-3">
          <label for="${prefix}-date">训练日期</label>
          <input class="input" id="${prefix}-date" name="date" type="date" max="${todayISO()}" value="${escapeAttr(dateValue)}" required>
        </div>
        <div class="field field-minutes span-2">
          <label for="${prefix}-minutes">时长 / 分钟</label>
          <input class="input" id="${prefix}-minutes" name="minutes" type="number" inputmode="numeric" min="1" max="1440" step="1" value="${escapeAttr(minutesValue)}" required>
        </div>
        <div class="field field-activity span-4">
          <label for="${prefix}-activity">训练内容 / 题目</label>
          <input class="input" id="${prefix}-activity" name="activity" type="text" maxlength="240" value="${escapeAttr(activityValue)}" placeholder="例：剑桥 18 Test 2 Section 3 精听" required>
        </div>
        <div class="field field-outcome span-3">
          <label for="${prefix}-outcome">完成情况</label>
          <select class="select" id="${prefix}-outcome" name="outcome" required>
            ${OUTCOME_KEYS.map((outcome) => `<option value="${outcome}" ${outcome === outcomeValue ? 'selected' : ''}>${OUTCOME_LABELS[outcome]}</option>`).join('')}
          </select>
        </div>
        <div class="field field-confidence span-3">
          <label for="${prefix}-confidence">本次把握度</label>
          <select class="select" id="${prefix}-confidence" name="confidence" required>
            ${[1, 2, 3, 4, 5].map((value) => `<option value="${value}" title="${CONFIDENCE_LABELS[value]}" ${Number(confidenceValue) === value ? 'selected' : ''}>${value} / 5 · ${compact ? CONFIDENCE_SHORT[value] : CONFIDENCE_LABELS[value]}</option>`).join('')}
          </select>
        </div>
        <div class="field field-notes span-6">
          <label for="${prefix}-notes">证据与复盘 <span class="field-hint">（可选）</span></label>
          <textarea class="textarea" id="${prefix}-notes" name="notes" maxlength="10000" placeholder="例：S3 错 2 题；转折词漏听；下次先看词性再看同义替换。口语可写题卡、卡顿点与重录句。">${escapeHTML(notesValue)}</textarea>
        </div>
      </div>
      ${task && !isEditing ? `
        <label class="checkbox-line" style="margin-top: 12px">
          <input type="checkbox" name="markDone" checked>
          <span>保存记录后，同时把“${escapeHTML(task.title)}”标为完成</span>
        </label>
      ` : ''}
      <div class="form-actions">
        <span class="form-hint">Ctrl / ⌘ + Enter 提交 · ${isEditing ? `正在修改 ${formatShortDate(editing.date)} 的记录` : '数据只写入这个浏览器'}</span>
        ${isEditing ? `<button class="btn btn-small" type="button" data-action="cancel-edit-session">取消修改</button>` : task ? `<button class="btn btn-small" type="button" data-action="close-task">收起</button>` : ''}
        <button class="btn btn-primary btn-small" type="submit">${isEditing ? '保存修改' : task ? '保存并完成' : '保存记录'}</button>
      </div>
    </form>
  `;
}

function renderEvidenceRail(stats, recommended) {
  const latest = stats.latestMock;
  const target = stats.targetBand;
  const week = currentPlanWeek();
  const weak = stats.weakPoints.length
    ? stats.weakPoints.map((item) => ({
        module: item.module,
        title: `${MODULE_META[item.module]?.label || '训练'} · ${item.activity}`,
        copy: `${item.count} 次低把握或受阻记录 · 最近 ${formatShortDate(item.lastDate)}`
      }))
    : state.settings.priorities.slice(0, 3).map((module) => ({
        module,
        title: `${MODULE_META[module].label} · ${MODULE_META[module].english}`,
        copy: PRIORITY_COPY[module]
      }));
  const focusWeight = allTasks().filter((task) => task.priority).length;
  const totalWeight = Math.max(1, allTasks().length);
  const priorityWeight = Math.round((focusWeight / totalWeight) * 100);
  const examCopy = stats.examDays === null
    ? '考试日未设置'
    : stats.examDays >= 0
      ? `距考试 ${stats.examDays} 天`
      : `考试日已过 ${Math.abs(stats.examDays)} 天`;
  return `
    <aside class="evidence-rail" aria-label="目标、弱项与本机证据">
      <section class="rail-block rail-target">
        <div class="rail-block-head">
          <h3>目标 ${formatBand(target)}</h3>
          <span>${week ? `W${String(week.number).padStart(2, '0')} · ${escapeHTML(week.phase.short)}` : '尚无计划'}</span>
        </div>
        <div class="target-line">
          <div>
            <h3>最近总分</h3>
            <p>${escapeHTML(examCopy)} · 四项必须齐全</p>
          </div>
          <span class="target-band ${latest ? '' : 'is-empty'}">${latest ? formatBand(stats.latestOverall) : '—'}</span>
        </div>
        <div class="target-compare">
          <div>
            <span>较上次模考</span>
            <b>${stats.mockDelta === null ? '—' : `${stats.mockDelta > 0 ? '+' : ''}${formatBand(stats.mockDelta)}`}</b>
            <small>${stats.previousOverall === null ? '还没有可比较记录' : `上次 ${formatBand(stats.previousOverall)}`}</small>
          </div>
          <div>
            <span>训练记录</span>
            <b>${stats.totalSessions}</b>
            <small>${stats.studyDays} 个学习日</small>
          </div>
        </div>
        <div class="module-scores" aria-label="各科最近模考分数">
          ${SCORE_MODULES.map((module) => {
            const score = latest ? Number(latest[module]) : null;
            const gap = score === null ? null : score - target;
            return `
              <div class="module-score">
                <span>${MODULE_META[module].short} · ${MODULE_META[module].label}</span>
                <b>${score === null ? '—' : formatBand(score)}</b>
                <small>${gap === null ? '待测' : `${gap >= 0 ? '+' : ''}${gap.toFixed(1)}`}</small>
              </div>
            `;
          }).join('')}
        </div>
      </section>

      <section class="rail-block rail-weak">
        <div class="rail-block-head">
          <h3>弱项优先</h3>
          <span>${stats.weakPoints.length ? '由记录推导' : '起始计划'}</span>
        </div>
        <div class="weak-list">
          ${weak.map((item, index) => `
            <div class="weak-item">
              <div>
                <b>${escapeHTML(item.title)}</b>
                <p>${escapeHTML(item.copy)}</p>
              </div>
              <em class="weak-priority">优先 ${String(index + 1).padStart(2, '0')}</em>
            </div>
          `).join('')}
        </div>
      </section>

      <section class="rail-block rail-evidence">
        <div class="rail-block-head">
          <h3>本机证据</h3>
          <span>自动保存</span>
        </div>
        <div class="rail-stats">
          <div class="rail-stat"><span>本周训练</span><b>${stats.weeklyMinutes}<small>MIN</small></b></div>
          <div class="rail-stat"><span>连续记录</span><b>${stats.streak}<small>天</small></b></div>
          <div class="rail-stat"><span>学习记录</span><b>${stats.totalSessions}<small>条</small></b></div>
          <div class="rail-stat"><span>本周完成</span><b>${stats.weekDone}<small>/ ${stats.weekTotal} 次</small></b></div>
        </div>
        <div class="weight-line">
          <span>计划权重</span>
          <span class="weight-track" aria-hidden="true"><i style="width:${priorityWeight}%;background:var(--cinnabar)"></i></span>
          <span>${priorityPhrase()} ${priorityWeight}%</span>
        </div>
      </section>

      <section class="rail-block rail-next">
        <div class="rail-block-head">
          <h3>下一步</h3>
          <span>${recommended?.module ? MODULE_META[recommended.module]?.short : '复盘'}</span>
        </div>
        <button class="next-action" type="button" data-action="${recommended?.id ? 'start-task' : 'tab'}" ${recommended?.id ? `data-task-id="${escapeAttr(recommended.id)}"` : 'data-tab="plan"'}>
          <span>${escapeHTML(recommended?.title || `进入 ${plan.length} 周计划，检查下一项训练`)}</span>
          <b>${recommended?.id ? '开始' : '查看'} ${icon('arrowRight', 11)}</b>
        </button>
        <p class="estimator-note">空白不等于 0 分。总分只在四项模考分数齐全后，由平均分四舍五入到 0.5 得出。</p>
      </section>
    </aside>
  `;
}

function renderDayEvidence(stats) {
  const meta = readSaveMeta();
  return `
    <footer class="day-evidence" aria-labelledby="evidence-title">
      <div>
        <h2 id="evidence-title">训练证据</h2>
        <p>${stats.totalSessions ? `已保存 ${stats.totalSessions} 条记录，共 ${formatDuration(stats.totalMinutes)}。` : '当前尚无学习数据。空状态不会伪造分数。'}</p>
        <div class="day-evidence-actions">
          <button class="text-button" type="button" data-action="tab" data-tab="log">打开全部记录</button>
          <span>最后导出：${meta?.lastExportedAt ? formatDateTime(meta.lastExportedAt) : '尚未'}</span>
        </div>
      </div>
      <div class="week-days" aria-label="最近七天训练记录">
        ${stats.recentDays.map((day) => {
          const isToday = day.date === todayISO();
          return `
            <div class="day-cell ${isToday ? 'is-today' : ''} ${day.count ? 'has-data' : ''}" title="${escapeAttr(day.date)} · ${day.minutes} 分钟 · ${day.count} 条记录">
              <span>${escapeHTML(formatWeekday(day.date).slice(-1))}</span>
              <b>${day.count ? `${day.minutes}m` : '—'}</b>
            </div>
          `;
        }).join('')}
      </div>
      <div class="evidence-stats">
        <div class="evidence-stat">
          <span>近 7 天训练</span>
          <b>${stats.recentDays.reduce((sum, day) => sum + day.minutes, 0)}<small> MIN</small></b>
          <small>${stats.recentDays.reduce((sum, day) => sum + day.count, 0)} 条记录</small>
        </div>
        <div class="evidence-stat">
          <span>完整模考</span>
          <b>${stats.totalMocks}</b>
          <small>${stats.totalMocks ? `最近 ${formatShortDate(stats.latestMock.date)}` : '尚无记录'}</small>
        </div>
        <div class="evidence-stat">
          <span>本周计划</span>
          <b>${stats.weekDone}</b>
          <small>/ ${stats.weekTotal} 次已完成</small>
        </div>
      </div>
    </footer>
  `;
}

function renderPlanView() {
  const currentWeek = currentPlanWeek();
  const doneTasks = plan.reduce((sum, week) => sum + weekEvidenceCount(week), 0);
  const totalTasks = plan.length * 6;
  const priorityTasks = allTasks().filter((task) => task.priority).length;
  const seenPhases = new Set();
  const pieces = [];

  for (const week of plan) {
    if (!seenPhases.has(week.phase.key)) {
      seenPhases.add(week.phase.key);
      const phaseWeeks = plan.filter((item) => item.phase.key === week.phase.key);
      pieces.push(`
        <div class="phase-band">
          <h3>${escapeHTML(week.phase.short)} · ${escapeHTML(week.phase.label)}</h3>
          <span>W${String(phaseWeeks[0].number).padStart(2, '0')}—W${String(phaseWeeks.at(-1).number).padStart(2, '0')}</span>
        </div>
      `);
    }
    const done = weekEvidenceCount(week);
    const isCurrent = week.number === currentWeek?.number;
    const isOpen = isCurrent || week.number === openWeekNumber;
    pieces.push(`
      <details class="week-entry ${isCurrent ? 'is-current' : ''}" data-week-entry="${week.number}" ${isOpen ? 'open' : ''}>
        <summary>
          <span class="week-index">W${String(week.number).padStart(2, '0')}</span>
          <div class="week-main">
            <div class="week-title-line">
              <h4>${escapeHTML(week.focus)}</h4>
              ${isCurrent ? '<span class="current-tag">本周</span>' : ''}
            </div>
            <div class="week-dates">${formatShortDate(week.startDate)}—${formatShortDate(week.endDate)} · ${escapeHTML(week.phase.label)}</div>
          </div>
          <div class="week-progress">
            <span class="week-progress-track" aria-hidden="true">${week.tasks.map((task) => `<i class="${isTaskDone(state, task.id) ? 'is-done' : ''}"></i>`).join('')}</span>
            <span>${done} / ${week.tasks.length}</span>
          </div>
          <span class="week-chevron" aria-hidden="true">${icon('chevronDown', 15)}</span>
        </summary>
        <div class="week-detail">
          <div class="week-tasks">
            ${week.tasks.map((task) => {
              const taskDone = isTaskDone(state, task.id);
              return `
                <div class="plan-task ${taskDone ? 'is-done' : ''}">
                  <input type="checkbox" data-action="toggle-task" data-task-id="${escapeAttr(task.id)}" ${taskDone ? 'checked' : ''} aria-label="${taskDone ? '取消完成' : '标记完成'}：${escapeAttr(task.title)}">
                  <div>
                    <p class="plan-task-title">${escapeHTML(task.title)}</p>
                    <div class="plan-task-meta">
                      <span>${MODULE_META[task.module].english.toUpperCase()}</span>
                      <span>${task.minutes} MIN</span>
                      <span>${formatShortDate(task.scheduledDate)}</span>
                      ${task.priority ? '<span style="color:var(--cinnabar-text)">优先</span>' : ''}
                    </div>
                  </div>
                  <div class="plan-task-end">
                    ${taskDone ? `<span style="color:var(--sage-text)">${icon('check', 12)} 已记录</span>` : ''}
                    <button class="btn btn-small btn-quiet" type="button" data-action="start-task" data-task-id="${escapeAttr(task.id)}">记录</button>
                  </div>
                </div>
              `;
            }).join('')}
          </div>
        </div>
      </details>
    `);
  }

  return `
    <section class="view" aria-labelledby="plan-heading">
      <header class="view-head">
        <div>
          <h2 id="plan-heading">${plan.length} 周训练计划</h2>
          <p>计划按周推进，${priorityModuleNames()}模块获得额外训练块。勾选只代表任务完成，训练质量仍由记录中的证据判断。</p>
        </div>
        <div class="view-count"><b>${doneTasks}</b><span>/ ${totalTasks} 次任务已完成</span></div>
      </header>

      <div class="plan-summary" aria-label="计划摘要">
        <div>
          <span>当前阶段</span>
          <b>${escapeHTML(currentWeek?.phase.short || '—')}</b>
          <small>${escapeHTML(currentWeek?.focus || '尚无当前周')}</small>
        </div>
        <div>
          <span>计划区间</span>
          <b>${formatShortDate(state.settings.planStart)}—${formatShortDate(plan.at(-1)?.endDate)}</b>
          <small>${plan.length} 周 · 每周 ${state.settings.weeklyHours} 小时</small>
        </div>
        <div>
          <span>计划完成</span>
          <b>${totalTasks ? Math.round((doneTasks / totalTasks) * 100) : 0}%</b>
          <small>${doneTasks} / ${totalTasks} 次</small>
        </div>
        <div>
          <span>优先任务占比</span>
          <b>${totalTasks ? Math.round((priorityTasks / totalTasks) * 100) : 0}%</b>
          <small>${priorityTasks} 个优先训练块</small>
        </div>
      </div>

      <div class="plan-ledger" aria-label="逐周训练任务">
        ${pieces.join('')}
      </div>
    </section>
  `;
}

function filteredSessions() {
  const cutoffDays = recordDays === 'all' ? null : Number(recordDays);
  const now = new Date();
  return [...state.sessions]
    .filter((session) => recordModule === 'all' || session.module === recordModule)
    .filter((session) => {
      if (!cutoffDays) return true;
      const age = dateDiffDays(session.date, now);
      return age !== null && age >= 0 && age < cutoffDays;
    })
    .sort((a, b) => {
      if (a.date !== b.date) return b.date.localeCompare(a.date);
      return String(b.createdAt).localeCompare(String(a.createdAt));
    });
}

function renderLogView() {
  const stats = getStats(state, plan, new Date());
  const sessions = filteredSessions();
  const editing = editingSessionId ? state.sessions.find((session) => session.id === editingSessionId) : null;
  return `
    <section class="view" aria-labelledby="log-heading">
      <header class="view-head">
        <div>
          <h2 id="log-heading">训练记录</h2>
          <p>在手机上快速记录，在电脑上检查时间分配、困难类型和下一步。删除可撤销；修改不会改变原记录的创建时间。</p>
        </div>
        <div class="view-count"><b>${stats.totalSessions}</b><span>条记录 · ${formatDuration(stats.totalMinutes)}</span></div>
      </header>

      <div class="stats-ledger" aria-label="训练记录摘要">
        <div>
          <span>总训练时长</span>
          <b>${Math.round(stats.totalMinutes / 60)}<small> H</small></b>
          <small>${stats.totalMinutes} 分钟</small>
        </div>
        <div>
          <span>学习日</span>
          <b>${stats.studyDays}</b>
          <small>有记录的自然日</small>
        </div>
        <div>
          <span>连续记录</span>
          <b>${stats.streak}</b>
          <small>截至今天/昨天</small>
        </div>
        <div>
          <span>困难或部分完成</span>
          <b>${state.sessions.filter((session) => session.outcome !== 'completed').length}</b>
          <small>用于弱项排序</small>
        </div>
      </div>

      <div class="review-layout">
        <div class="review-main">
          <div class="section-head">
            <div>
              <h3>记录清单</h3>
              <p>按日期倒序；筛选只影响当前列表，不会删除数据。</p>
            </div>
            <span>${sessions.length} 条可见</span>
          </div>
          <div class="filter-bar">
            <div class="field">
              <label for="filter-module">模块</label>
              <select class="select" id="filter-module" data-filter="module">
                <option value="all" ${recordModule === 'all' ? 'selected' : ''}>全部模块</option>
                ${SESSION_MODULES.map((module) => `<option value="${module}" ${recordModule === module ? 'selected' : ''}>${MODULE_META[module].label}</option>`).join('')}
              </select>
            </div>
            <div class="field">
              <label for="filter-days">时间范围</label>
              <select class="select" id="filter-days" data-filter="days">
                <option value="7" ${recordDays === '7' ? 'selected' : ''}>最近 7 天</option>
                <option value="30" ${recordDays === '30' ? 'selected' : ''}>最近 30 天</option>
                <option value="90" ${recordDays === '90' ? 'selected' : ''}>最近 90 天</option>
                <option value="all" ${recordDays === 'all' ? 'selected' : ''}>全部时间</option>
              </select>
            </div>
            <span class="filter-count">${sessions.length} / ${state.sessions.length} 条</span>
          </div>
          ${sessions.length ? renderRecordsTable(sessions) : renderRecordsEmpty()}
        </div>
        <aside class="review-side">
          <div class="form-panel">
            <div class="form-panel-head">
              <div>
                <h3>${editing ? '修改训练记录' : '新增训练记录'}</h3>
                <p>${editing ? `正在修改 ${formatFullDate(editing.date)} 的记录。` : '口语写题卡与卡顿点，写作写题目与修改动作。'}</p>
              </div>
              ${editing ? `<span class="mini-mark">EDIT</span>` : ''}
            </div>
            ${renderSessionForm({ prefix: 'log', editing })}
          </div>
        </aside>
      </div>
    </section>
  `;
}

function renderRecordsEmpty() {
  return `
    <div class="empty-state">
      <span class="empty-glyph">${icon('archive', 20)}</span>
      <h3>没有符合筛选条件的记录</h3>
      <p>先完成一次训练并记录证据，或放宽筛选条件。空记录不会被当作 0 分钟或 0 分处理。</p>
      ${state.sessions.length ? '<button class="btn" type="button" data-action="clear-filters">查看全部记录</button>' : '<button class="btn" type="button" data-action="tab" data-tab="today">回到今日训练</button>'}
    </div>
  `;
}

function renderRecordsTable(sessions) {
  return `
    <div class="record-table-wrap">
      <table class="record-table">
        <thead>
          <tr>
            <th scope="col">日期</th>
            <th scope="col">模块</th>
            <th scope="col">训练内容与证据</th>
            <th scope="col">时长</th>
            <th scope="col">完成情况</th>
            <th scope="col">把握度</th>
            <th scope="col"><span class="sr-only">操作</span></th>
          </tr>
        </thead>
        <tbody>
          ${sessions.map((session) => {
            const note = (session.notes || '').replace(/\s+/g, ' ').trim();
            return `
              <tr>
                <td data-label="日期"><span class="record-date">${formatShortDate(session.date)}<br>${escapeHTML(formatWeekday(session.date))}</span></td>
                <td data-label="模块">${moduleLabel(session.module, true)}</td>
                <td class="record-activity" data-label="内容">
                  <strong>${escapeHTML(session.activity)}</strong>
                  ${note ? `<small>${escapeHTML(note.length > 150 ? `${note.slice(0, 150)}…` : note)}</small>` : ''}
                </td>
                <td data-label="时长"><span class="record-minutes">${session.minutes} MIN</span></td>
                <td data-label="完成"><span class="outcome is-${escapeAttr(session.outcome)}">${escapeHTML(OUTCOME_LABELS[session.outcome])}</span></td>
                <td data-label="把握度"><span class="confidence">${session.confidence} / 5</span></td>
                <td class="record-actions">
                  <div class="row-actions">
                    <button class="icon-button" type="button" data-action="edit-session" data-session-id="${escapeAttr(session.id)}" aria-label="修改这条记录" title="修改">${icon('edit', 14)}</button>
                    <button class="icon-button" type="button" data-action="delete-session" data-session-id="${escapeAttr(session.id)}" aria-label="删除这条记录" title="删除">${icon('trash', 14)}</button>
                  </div>
                </td>
              </tr>
            `;
          }).join('')}
        </tbody>
      </table>
    </div>
  `;
}

function bandOptions(selected = '', includeBlank = true) {
  const options = includeBlank ? ['<option value="">—</option>'] : [];
  for (let index = 0; index <= 18; index += 1) {
    const value = index / 2;
    const numeric = Number(selected);
    const isSelected = selected !== '' && Number.isFinite(numeric) && Math.abs(numeric - value) < 0.001;
    options.push(`<option value="${value.toFixed(1)}" ${isSelected ? 'selected' : ''}>${value.toFixed(1)}</option>`);
  }
  return options.join('');
}

function renderMockView() {
  const stats = getStats(state, plan, new Date());
  const latest = stats.latestMock;
  const editing = editingMockId ? state.mocks.find((mock) => mock.id === editingMockId) : null;
  return `
    <section class="view" aria-labelledby="mock-heading">
      <header class="view-head">
        <div>
          <h2 id="mock-heading">模考与分数证据</h2>
          <p>只有四项分数齐全才计算总分。总分是四项平均后四舍五入到 0.5，不据此预测未来成绩。</p>
        </div>
        <div class="view-count"><b>${stats.totalMocks}</b><span>次完整模考</span></div>
      </header>

      <div class="mock-hero">
        <div class="mock-hero-copy">
          <h3>${latest ? `最近一次 · ${formatFullDate(latest.date)}` : '还没有完整模考'}</h3>
          <p>${latest ? `${formatBand(stats.latestOverall)} 总分 · 目标 ${formatBand(stats.targetBand)} · 不代替官方成绩` : '第一次模考用于建立基线。没有录入前，不展示推测分。'}</p>
        </div>
        <div class="mock-overall">
          <span>OVERALL</span>
          <b>${latest ? formatBand(stats.latestOverall) : '—'}</b>
        </div>
        <div class="mock-delta">
          <span>较上次</span>
          <b class="${stats.mockDelta !== null && stats.mockDelta < 0 ? 'is-negative' : ''}">${stats.mockDelta === null ? '—' : `${stats.mockDelta > 0 ? '+' : ''}${formatBand(stats.mockDelta)}`}</b>
        </div>
      </div>

      <div class="mock-score-grid" aria-label="最近模考各科分数">
        ${SCORE_MODULES.map((module) => {
          const value = latest ? Number(latest[module]) : null;
          const gap = value === null ? null : value - stats.targetBand;
          return `
            <div class="mock-score-cell">
              <span>${moduleIcon(module, 12)} ${MODULE_META[module].label}</span>
              <b>${value === null ? '—' : formatBand(value)}</b>
              <small>${gap === null ? '等待基线' : `目标差 ${gap >= 0 ? '+' : ''}${gap.toFixed(1)}`}</small>
            </div>
          `;
        }).join('')}
      </div>

      <div class="review-layout">
        <div class="review-main">
          <div class="section-head">
            <div>
              <h3>模考历史</h3>
              <p>只用于复盘证据。可以用备注记录难度、状态和考试条件。</p>
            </div>
            <span>${state.mocks.length} 条</span>
          </div>
          ${state.mocks.length ? renderMockHistory() : `
            <div class="empty-state">
              <span class="empty-glyph">${icon('check', 20)}</span>
              <h3>尚无完整模考</h3>
              <p>完成一次四项齐全的 A 类模考后录入。若只想记录单科练习，请使用“训练记录”。</p>
              <button class="btn" type="button" data-action="focus-mock-form">录入第一场模考</button>
            </div>
          `}
        </div>
        <aside class="review-side" id="mock-form">
          <div class="form-panel">
            <div class="form-panel-head">
              <div>
                <h3>${editing ? '修改模考记录' : '录入完整模考'}</h3>
                <p>四项分数必须齐全，分数按 0.5 递增。</p>
              </div>
              ${editing ? '<span class="mini-mark">EDIT</span>' : ''}
            </div>
            ${renderMockForm(editing)}
          </div>
        </aside>
      </div>
    </section>
  `;
}

function renderMockForm(editing = null) {
  const dateValue = editing?.date || todayISO();
  return `
    <form data-form="mock" data-prefix="mock">
      <input type="hidden" name="mockId" value="${escapeAttr(editing?.id || '')}">
      <div class="form-grid">
        <div class="field span-6">
          <label for="mock-date">模考日期</label>
          <input class="input" id="mock-date" name="date" type="date" max="${todayISO()}" value="${escapeAttr(dateValue)}" required>
        </div>
        <div class="field span-6">
          <label for="mock-target-note">记录边界</label>
          <input class="input" id="mock-target-note" type="text" value="四项齐全才计算总分" disabled>
        </div>
        ${SCORE_MODULES.map((module) => `
          <div class="field span-3">
            <label for="mock-${module}">${MODULE_META[module].label} / ${MODULE_META[module].english}</label>
            <select class="select" id="mock-${module}" name="${module}" data-score-input required>
              ${bandOptions(editing?.[module] || '', true)}
            </select>
          </div>
        `).join('')}
        <div class="field span-12">
          <label for="mock-notes">考试条件与复盘 <span class="field-hint">（可选）</span></label>
          <textarea class="textarea" id="mock-notes" name="notes" maxlength="10000" placeholder="例：上午状态；阅读第三篇超时；口语 Part 3 例证不足。">${escapeHTML(editing?.notes || '')}</textarea>
        </div>
      </div>
      <div class="score-preview" aria-live="polite">
        <span>总分预览 · 四项平均后取 0.5</span>
        <b class="score-preview-value">—</b>
        <small class="score-preview-gap">目标 ${formatBand(state.settings.targetBand)}</small>
      </div>
      <div class="form-actions">
        <span class="form-hint">Ctrl / ⌘ + Enter 提交</span>
        ${editing ? '<button class="btn btn-small" type="button" data-action="cancel-edit-mock">取消修改</button>' : ''}
        <button class="btn btn-primary btn-small" type="submit">${editing ? '保存修改' : '保存模考'}</button>
      </div>
    </form>
  `;
}

function renderMockHistory() {
  const mocks = [...state.mocks].sort((a, b) => {
    if (a.date !== b.date) return b.date.localeCompare(a.date);
    return String(b.createdAt).localeCompare(String(a.createdAt));
  });
  return `
    <div class="mock-history" role="region" aria-label="模考历史" tabindex="0">
      <div class="mock-row mock-row-head" aria-hidden="true">
        <span>日期</span><span>备注</span><span>L</span><span>S</span><span>R</span><span>W</span><span>总分</span><span></span>
      </div>
      ${mocks.map((mock) => {
        const overall = calculateOverallBand(mock);
        const note = (mock.notes || '').replace(/\s+/g, ' ').trim();
        return `
          <div class="mock-row">
            <span class="mock-row-date">${formatShortDate(mock.date)}</span>
            <span class="mock-row-note" title="${escapeAttr(note || '无备注')}">${escapeHTML(note || '无备注')}</span>
            ${SCORE_MODULES.map((module) => `<span class="mock-row-score">${formatBand(mock[module])}</span>`).join('')}
            <span class="mock-row-overall">${formatBand(overall)}</span>
            <span class="mock-row-actions">
              <button class="icon-button" type="button" data-action="edit-mock" data-mock-id="${escapeAttr(mock.id)}" aria-label="修改这次模考" title="修改">${icon('edit', 14)}</button>
              <button class="icon-button" type="button" data-action="delete-mock" data-mock-id="${escapeAttr(mock.id)}" aria-label="删除这次模考" title="删除">${icon('trash', 14)}</button>
            </span>
          </div>
        `;
      }).join('')}
    </div>
  `;
}

function renderSettingsView() {
  return `
    <section class="view" aria-labelledby="settings-heading">
      <header class="view-head">
        <div>
          <h2 id="settings-heading">计划与数据设置</h2>
          <p>调整考试目标、计划起点与每周投入。所有数据保存在当前浏览器，跨设备请显式导出与导入。</p>
        </div>
        <div class="view-count"><b>${state.sessions.length}</b><span>条记录 · ${state.mocks.length} 次模考</span></div>
      </header>

      <div class="settings-layout">
        <div>
          <div class="settings-panel">
            <div class="settings-panel-head">
              <h3>训练计划</h3>
              <p>修改后立即重排 ${plan.length} 周路线。已有训练记录与已完成勾选不会删除；完成勾选按周次保留。</p>
            </div>
            <form data-form="settings">
              <div class="form-grid">
                <div class="field span-6">
                  <label for="settings-exam-date">考试日期 <span class="field-hint">（可选）</span></label>
                  <input class="input" id="settings-exam-date" name="examDate" type="date" min="${escapeAttr(state.settings.planStart)}" value="${escapeAttr(state.settings.examDate)}">
                  <span class="field-hint">目标为 2027 年夏季考试；具体日期未确定可留空。</span>
                </div>
                <div class="field span-3">
                  <label for="settings-target">目标总分</label>
                  <select class="select" id="settings-target" name="targetBand" required>
                    ${bandOptions(state.settings.targetBand, false)}
                  </select>
                </div>
                <div class="field span-3">
                  <label for="settings-weekly-hours">每周投入 / 小时</label>
                  <input class="input" id="settings-weekly-hours" name="weeklyHours" type="number" inputmode="numeric" min="4" max="40" step="1" value="${state.settings.weeklyHours}" required>
                </div>
                <div class="field span-4">
                  <label for="settings-plan-start">计划起始日</label>
                  <input class="input" id="settings-plan-start" name="planStart" type="date" value="${escapeAttr(state.settings.planStart)}" required>
                </div>
                <div class="field span-4">
                  <label for="settings-plan-weeks">计划周数</label>
                  <input class="input" id="settings-plan-weeks" name="planWeeks" type="number" inputmode="numeric" min="4" max="52" step="1" value="${state.settings.planWeeks}" required>
                  <span class="field-hint">4 个月建议 16 周。</span>
                </div>
                <div class="field span-4">
                  <span class="field-label">计划重心</span>
                  <div class="choice-row">
                    ${PRIORITY_MODULES.map((module) => `
                      <label class="choice-chip">
                        <input type="checkbox" name="priorities" value="${module}" ${state.settings.priorities.includes(module) ? 'checked' : ''}>
                        <span>${moduleIcon(module, 12)} ${MODULE_META[module].label}</span>
                      </label>
                    `).join('')}
                  </div>
                  <span class="field-hint">至少选择 1 项；听力与口语默认加权。</span>
                </div>
              </div>
              <div class="form-actions">
                <span class="form-hint">修改日期会移动未执行任务的日期；不会清除训练记录。</span>
                <button class="btn btn-primary" type="submit">保存计划设置</button>
              </div>
            </form>
          </div>

          <div class="settings-panel">
            <div class="settings-panel-head">
              <h3>记录规范</h3>
              <p>训练台只记录可复核的证据，不自动给口语或写作打分。</p>
            </div>
            <ol class="load-sequence">
              <li><span>听力：写下漏听词、同义替换和题号，而不是只写“错几题”。</span><b>EVIDENCE</b></li>
              <li><span>口语：保留题卡、卡顿位置、重复表达和一次重录动作。</span><b>SPEAKING</b></li>
              <li><span>阅读：每道错题标出原文证据句，并归类错误类型。</span><b>READING</b></li>
              <li><span>写作：记录题目、任务回应缺口和下一版只改什么。</span><b>WRITING</b></li>
              <li><span>模考：四项分数齐全才计算总分，不展示推测成绩。</span><b>MOCK</b></li>
            </ol>
          </div>
        </div>
        ${renderSettingsAside()}
      </div>
    </section>
  `;
}

function renderSettingsAside() {
  const meta = readSaveMeta();
  const doneTasks = plan.reduce((sum, week) => sum + weekEvidenceCount(week), 0);
  const bytes = new Blob([JSON.stringify(state)]).size;
  return `
    <aside class="settings-aside">
      <div class="settings-panel">
        <div class="settings-panel-head">
          <h3>本机数据</h3>
          <p>没有账号，没有远程数据库。保存只发生在这个浏览器。</p>
        </div>
        <div class="data-status">
          ${icon('db', 16)}
          <div>
            <strong>${saveError ? '本机保存异常' : '本机存储已启用'}</strong>
            ${saveError ? escapeHTML(saveError) : meta?.lastSavedAt ? `最近保存 ${formatDateTime(meta.lastSavedAt)}` : '等待第一次改动'}
          </div>
        </div>
        <dl class="data-list">
          <dt>训练记录</dt><dd>${state.sessions.length} 条</dd>
          <dt>完整模考</dt><dd>${state.mocks.length} 次</dd>
          <dt>已完成任务</dt><dd>${doneTasks} 个</dd>
          <dt>单词复习</dt><dd>${Object.keys(state.vocabulary.progress).length} 张</dd>
          <dt>听写记录</dt><dd>${state.listeningAttempts.length} 次</dd>
          <dt>口试记录</dt><dd>${state.speakingTakes.length} 次</dd>
          <dt>数据体积</dt><dd>${bytes < 1024 ? `${bytes} B` : `${(bytes / 1024).toFixed(1)} KB`}</dd>
          <dt>最后导出</dt><dd>${meta?.lastExportedAt ? formatDateTime(meta.lastExportedAt) : '尚未'}</dd>
        </dl>
        <div class="data-actions">
          <button class="btn" type="button" data-action="export">${icon('download', 14)}导出 JSON</button>
          <button class="btn" type="button" data-action="import">${icon('upload', 14)}导入进度</button>
        </div>
      </div>

      <div class="settings-panel">
        <div class="settings-panel-head">
          <h3>手机与电脑之间</h3>
          <p>使用版本化 JSON 文件显式迁移，不依赖云同步。</p>
        </div>
        <ol class="load-sequence">
          <li><span>在已更新的设备导出 JSON。</span><b>01</b></li>
          <li><span>在另一台设备导入；跨设备首次迁移建议“替换”。</span><b>02</b></li>
          <li><span>两边都有新记录时选择“合并”，按记录 ID 去重。</span><b>03</b></li>
          <li><span>完成一轮重要训练后再次导出，保留独立备份。</span><b>04</b></li>
        </ol>
      </div>

      <div class="settings-panel">
        <div class="settings-panel-head">
          <h3>重置</h3>
          <p>清理浏览器站点数据也会删除本机进度；重置前请先导出。</p>
        </div>
        <div class="danger-zone">
          <h4>永久清除全部进度</h4>
          <p>训练记录、模考、单词间隔、听写、口试元数据、计划设置与完成勾选都会移除。这个动作需要输入确认文字。</p>
          <button class="btn btn-danger" type="button" data-action="reset-open">${icon('trash', 14)}清除本机进度</button>
        </div>
      </div>
    </aside>
  `;
}

function stopSpeechPlayback() {
  if ('speechSynthesis' in window) window.speechSynthesis.cancel();
  document.querySelector('[data-listen-wave]')?.classList.remove('is-playing');
}

function setListeningStatus(message) {
  const node = document.querySelector('[data-listening-status]');
  if (node) node.textContent = message;
}

function playListeningSentence(slow = false) {
  if (!('speechSynthesis' in window) || typeof SpeechSynthesisUtterance === 'undefined') {
    showToast('当前浏览器没有语音合成。请改用 Safari 或 Chrome，或把这句原文交给系统朗读。', { type: 'error', duration: 8000 });
    return;
  }
  const drill = currentListeningDrill();
  if (!drill) return;
  window.speechSynthesis.cancel();
  const utterance = new SpeechSynthesisUtterance(drill.sentence);
  utterance.lang = 'en-GB';
  utterance.rate = slow ? 0.72 : 0.9;
  utterance.pitch = 1;
  const voices = window.speechSynthesis.getVoices().filter((voice) => /^en([-_]|$)/i.test(voice.lang));
  const voice = voices.find((item) => /^en[-_]GB/i.test(item.lang))
    || voices.find((item) => /^en[-_]AU/i.test(item.lang))
    || voices.find((item) => /^en[-_]US/i.test(item.lang))
    || voices[0];
  if (voice) utterance.voice = voice;
  const wave = document.querySelector('[data-listen-wave]');
  const startingMessage = slow ? '正在慢速播放 · 捕捉连读与词尾' : '正在播放 · 先听完整句，不急着写';
  wave?.classList.add('is-playing');
  setListeningStatus(startingMessage);
  utterance.onend = () => {
    wave?.classList.remove('is-playing');
    setListeningStatus('播放结束 · 写完整句后再核对原文');
  };
  utterance.onerror = (event) => {
    wave?.classList.remove('is-playing');
    if (event.error === 'canceled' || event.error === 'interrupted') return;
    setListeningStatus('系统语音未能播放 · 请检查静音开关或换一个浏览器');
    showToast('语音播放失败。计时与听写输入仍可继续使用。', { type: 'error' });
  };
  window.speechSynthesis.speak(utterance);
}

function chooseListeningDrill(drillId) {
  const drill = LISTENING_DRILLS.find((item) => item.id === drillId);
  if (!drill) return;
  stopSpeechPlayback();
  listeningDrillId = drill.id;
  listeningStartedAt = Date.now();
  dictationChecked = false;
  dictationResult = null;
  dictationAnswer = '';
  render({ scrollMode: 'preserve', focusSelector: '#dictation-answer' });
}

function rateVocabulary(cardId, rating) {
  const card = getVocabularyCard(state, cardId);
  if (!card || !VOCAB_RATINGS[rating]) return;
  const previous = state.vocabulary.progress[cardId] || null;
  const next = reviewVocabularyCard(previous, cardId, rating, new Date());
  state.vocabulary.progress[cardId] = next;
  vocabularyRevealed = false;
  vocabularyCardId = null;
  const undo = () => {
    if (previous) state.vocabulary.progress[cardId] = previous;
    else delete state.vocabulary.progress[cardId];
    vocabularyCardId = cardId;
    vocabularyRevealed = true;
    persist();
    render();
    showToast('已恢复到本次复习前');
  };
  finishMutation(`已记录“${VOCAB_RATINGS[rating].label}” · ${VOCAB_RATINGS[rating].hint}`, {
    actionLabel: '撤销',
    onAction: undo
  });
}

function disposeSpeakingRuntime() {
  speakingRunToken += 1;
  if (speakingTimer) {
    window.clearInterval(speakingTimer);
    speakingTimer = null;
  }
  if (mediaRecorder) {
    mediaRecorder.ondataavailable = null;
    mediaRecorder.onerror = null;
    try {
      if (mediaRecorder.state !== 'inactive') mediaRecorder.stop();
    } catch {
      // The recorder may already be closing after a browser-level interruption.
    }
    mediaRecorder = null;
  }
  mediaStream?.getTracks().forEach((track) => track.stop());
  mediaStream = null;
  recordingChunks = [];
  if (recordedUrl) URL.revokeObjectURL(recordedUrl);
  recordedUrl = '';
  recordingState = 'idle';
  speakingPhase = 'idle';
  speakingRemaining = 0;
  speakingTotal = 0;
  speakingDeadline = 0;
  speakingPrepStartedAt = null;
  speakingAnswerStartedAt = null;
  speakingPrepUsed = 0;
  speakingDurationSec = 0;
  speakingStarting = false;
  speakingStatusNote = '';
}

function leavePracticeRuntime() {
  stopSpeechPlayback();
  disposeSpeakingRuntime();
}

function setPracticeMode(mode) {
  if (!['vocabulary', 'listening', 'speaking'].includes(mode)) return;
  if (mode === practiceMode) return;
  if (practiceMode === 'speaking' || mode === 'speaking') {
    disposeSpeakingRuntime();
  }
  if (practiceMode === 'listening' || mode === 'listening') stopSpeechPlayback();
  practiceMode = mode;
  render({ scrollMode: 'preserve' });
}

function updateSpeakingTimerUI() {
  const timer = document.querySelector('[data-speaking-timer]');
  const fill = document.querySelector('[data-speaking-fill]');
  const flag = document.querySelector('[data-recording-flag]');
  if (timer && speakingPhase !== 'idle') timer.textContent = formatClock(speakingRemaining);
  if (fill && speakingPhase !== 'idle') {
    const percent = speakingTotal ? Math.max(0, Math.min(100, (speakingRemaining / speakingTotal) * 100)) : 0;
    fill.style.width = `${percent}%`;
  }
  if (flag) {
    flag.classList.toggle('is-live', recordingState === 'recording');
    const label = recordingState === 'recording'
      ? 'REC'
      : recordingState === 'ready'
        ? 'AUDIO READY'
        : recordingState === 'denied'
          ? 'MIC BLOCKED'
          : 'LOCAL ONLY';
    const textNode = flag.lastChild;
    if (textNode) textNode.textContent = label;
    else flag.append(document.createTextNode(label));
  }
}

function startSpeakingClock(phase, seconds) {
  if (speakingTimer) window.clearInterval(speakingTimer);
  speakingPhase = phase;
  speakingTotal = Math.max(0, Math.round(Number(seconds) || 0));
  speakingRemaining = speakingTotal;
  speakingDeadline = Date.now() + speakingTotal * 1000;
  updateSpeakingTimerUI();
  speakingTimer = window.setInterval(() => {
    speakingRemaining = Math.max(0, Math.ceil((speakingDeadline - Date.now()) / 1000));
    updateSpeakingTimerUI();
    if (speakingRemaining > 0) return;
    window.clearInterval(speakingTimer);
    speakingTimer = null;
    if (speakingPhase === 'prep') {
      speakingPhase = 'ready';
      speakingStatusNote = '';
      render({ scrollMode: 'preserve' });
      showToast('准备时间结束 · 现在开始作答');
    } else if (speakingPhase === 'answer') {
      void finishSpeakingAnswer();
    }
  }, 250);
}

function beginSpeakingPrep() {
  const prompt = currentSpeakingPrompt();
  if (!['idle', 'prep', 'ready'].includes(speakingPhase)) return;
  speakingPrepStartedAt = Date.now();
  speakingPrepUsed = 0;
  speakingStatusNote = '';
  startSpeakingClock('prep', prompt.prepSec);
  render({ scrollMode: 'preserve' });
}

function recordingSupportMessage() {
  if (!window.isSecureContext) return '当前页面不是安全连接，浏览器不会开放麦克风；计时与笔记仍可使用。';
  if (!navigator.mediaDevices?.getUserMedia) return '当前浏览器不支持麦克风采集；计时与笔记仍可使用。';
  if (typeof MediaRecorder === 'undefined') return '当前浏览器不支持录音编码；计时与笔记仍可使用。';
  return '';
}

async function startSpeakingRecording() {
  const unsupported = recordingSupportMessage();
  if (unsupported) {
    recordingState = 'unsupported';
    speakingStatusNote = unsupported;
    return false;
  }
  let request = null;
  try {
    request = navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true } });
    let timeoutId = null;
    const timeout = new Promise((_, reject) => {
      timeoutId = window.setTimeout(() => {
        const error = new Error('Microphone permission request timed out');
        error.name = 'TimeoutError';
        reject(error);
      }, 8000);
    });
    try {
      mediaStream = await Promise.race([request, timeout]);
    } finally {
      if (timeoutId) window.clearTimeout(timeoutId);
    }
    const candidates = ['audio/mp4;codecs=mp4a.40.2', 'audio/webm;codecs=opus', 'audio/webm', 'audio/ogg;codecs=opus'];
    const mimeType = candidates.find((type) => typeof MediaRecorder.isTypeSupported !== 'function' || MediaRecorder.isTypeSupported(type));
    const recorder = mimeType ? new MediaRecorder(mediaStream, { mimeType }) : new MediaRecorder(mediaStream);
    recordingChunks = [];
    recorder.addEventListener('dataavailable', (event) => {
      if (event.data?.size) recordingChunks.push(event.data);
    });
    recorder.addEventListener('error', () => {
      recordingState = 'error';
      speakingStatusNote = '录音过程中出现浏览器错误；计时与笔记仍可保存。';
      updateSpeakingTimerUI();
    });
    recorder.start(500);
    mediaRecorder = recorder;
    recordingState = 'recording';
    speakingStatusNote = '';
    return true;
  } catch (error) {
    mediaStream?.getTracks().forEach((track) => track.stop());
    mediaStream = null;
    recordingState = error?.name === 'NotAllowedError' || error?.name === 'SecurityError' ? 'denied' : 'error';
    speakingStatusNote = recordingState === 'denied'
      ? '麦克风权限未开启。计时与笔记照常保存；如需录音，请在浏览器站点设置中允许麦克风。'
      : error?.name === 'TimeoutError'
        ? '麦克风授权等待超时。已切换为只计时模式，自评与笔记仍可保存。'
        : '无法启动麦克风。计时与笔记照常保存。';
    if (error?.name === 'TimeoutError' && request) {
      request.then((stream) => stream.getTracks().forEach((track) => track.stop())).catch(() => {});
    }
    return false;
  }
}

function stopSpeakingRecording() {
  const recorder = mediaRecorder;
  const token = speakingRunToken;
  if (!recorder || recorder.state === 'inactive') {
    mediaStream?.getTracks().forEach((track) => track.stop());
    mediaStream = null;
    if (!recordedUrl && recordingState === 'recording') recordingState = 'idle';
    return Promise.resolve();
  }
  return new Promise((resolve) => {
    const finish = () => {
      const blob = new Blob(recordingChunks, { type: recorder.mimeType || 'audio/webm' });
      recordingChunks = [];
      if (recordedUrl) URL.revokeObjectURL(recordedUrl);
      recordedUrl = blob.size ? URL.createObjectURL(blob) : '';
      recordingState = recordedUrl ? 'ready' : 'error';
      if (!recordedUrl) speakingStatusNote = '这次没有捕获到音频，但计时与笔记仍可保存。';
      mediaRecorder = null;
      mediaStream?.getTracks().forEach((track) => track.stop());
      mediaStream = null;
      if (token !== speakingRunToken) {
        if (recordedUrl) URL.revokeObjectURL(recordedUrl);
        recordedUrl = '';
        recordingState = 'idle';
        speakingStatusNote = '';
      }
      resolve();
    };
    recorder.addEventListener('stop', finish, { once: true });
    try {
      recorder.stop();
    } catch {
      finish();
    }
  });
}

async function startSpeakingAnswer({ skipRecording = false } = {}) {
  if (speakingStarting || ['answer', 'requesting', 'processing'].includes(speakingPhase)) return;
  const prompt = currentSpeakingPrompt();
  const token = ++speakingRunToken;
  if (speakingTimer) window.clearInterval(speakingTimer);
  speakingTimer = null;
  if (speakingPhase === 'prep' && speakingPrepStartedAt) {
    speakingPrepUsed = Math.min(prompt.prepSec, Math.max(0, Math.round((Date.now() - speakingPrepStartedAt) / 1000)));
  } else if (speakingPhase === 'ready') {
    speakingPrepUsed = prompt.prepSec;
  } else {
    speakingPrepUsed = 0;
  }
  if (skipRecording) {
    speakingStarting = false;
    speakingAnswerStartedAt = Date.now();
    recordingState = 'skipped';
    speakingStatusNote = '已跳过录音；本次只记录时长、自评和复盘笔记。';
    startSpeakingClock('answer', prompt.speakSec);
    render({ scrollMode: 'preserve' });
    return;
  }
  speakingStarting = true;
  speakingPhase = 'requesting';
  speakingStatusNote = '';
  render({ scrollMode: 'preserve' });
  const recorded = await startSpeakingRecording();
  if (token !== speakingRunToken || activeTab !== 'practice' || practiceMode !== 'speaking') {
    mediaStream?.getTracks().forEach((track) => track.stop());
    try {
      if (mediaRecorder && mediaRecorder.state !== 'inactive') mediaRecorder.stop();
    } catch {
      // The permission request may resolve after the practice view has closed.
    }
    mediaStream = null;
    mediaRecorder = null;
    recordingChunks = [];
    recordingState = 'idle';
    speakingStatusNote = '';
    return;
  }
  speakingStarting = false;
  speakingAnswerStartedAt = Date.now();
  speakingStatusNote = recorded ? '' : speakingStatusNote;
  startSpeakingClock('answer', prompt.speakSec);
  render({ scrollMode: 'preserve' });
}

async function finishSpeakingAnswer() {
  if (speakingPhase !== 'answer') return;
  const token = speakingRunToken;
  const prompt = currentSpeakingPrompt();
  speakingDurationSec = speakingAnswerStartedAt
    ? Math.min(prompt.speakSec + 10, Math.max(0, Math.round((Date.now() - speakingAnswerStartedAt) / 1000)))
    : Math.max(0, speakingTotal - speakingRemaining);
  if (speakingTimer) window.clearInterval(speakingTimer);
  speakingTimer = null;
  speakingPhase = 'processing';
  speakingStatusNote = '';
  render({ scrollMode: 'preserve' });
  await stopSpeakingRecording();
  if (token !== speakingRunToken) return;
  speakingPhase = 'done';
  speakingRemaining = 0;
  speakingStatusNote = '';
  render({ scrollMode: 'preserve' });
}

function handleVocabularyCustomSubmit(form) {
  const data = new FormData(form);
  const term = String(data.get('term') || '').trim().slice(0, 80);
  const meaning = String(data.get('meaning') || '').trim().slice(0, 240);
  const example = String(data.get('example') || '').trim().slice(0, 500);
  if (!term) return formFailure(form, '请填写要加入的单词或短语。', 'term');
  if (!meaning) return formFailure(form, '请填写中文释义，否则词卡无法用于回忆。', 'meaning');
  const duplicate = getVocabularyCards(state).some((card) => card.term.toLowerCase() === term.toLowerCase());
  if (duplicate) return formFailure(form, '词库中已有这个单词或短语。', 'term');
  const word = {
    id: makeId('custom-word'),
    term,
    phonetic: '',
    part: 'word',
    meaning,
    collocation: '',
    example,
    translation: '',
    createdAt: new Date().toISOString()
  };
  state.vocabulary.customWords.push(word);
  vocabularyCardId = word.id;
  vocabularyRevealed = false;
  const undo = () => {
    state.vocabulary.customWords = state.vocabulary.customWords.filter((item) => item.id !== word.id);
    delete state.vocabulary.progress[word.id];
    vocabularyCardId = null;
    persist();
    render();
    showToast('已移除刚加入的词条');
  };
  finishMutation('自建词条已加入词库', { actionLabel: '撤销', onAction: undo });
}

function handleDictationSubmit(form, submitter) {
  const data = new FormData(form);
  const answer = String(data.get('answer') || '').trim().slice(0, 2000);
  if (!answer) return formFailure(form, '请先写下你听到的句子。', 'answer');
  const drill = currentListeningDrill();
  if (!drill) return;
  dictationAnswer = answer;
  const result = compareDictation(drill.sentence, answer);
  const intent = submitter?.value || 'check';
  if (intent === 'check') {
    dictationChecked = true;
    dictationResult = result;
    render({ scrollMode: 'preserve' });
    requestAnimationFrame(() => document.querySelector('.dictation-result')?.focus({ preventScroll: true }));
    return;
  }
  if (!dictationChecked) return formFailure(form, '先核对一次听写，再保存结果。', 'answer');
  const rating = Number(data.get('rating') || 3);
  if (!Number.isInteger(rating) || rating < 1 || rating > 5) return formFailure(form, '请选择 1—5 的本次把握度。', 'rating');
  const attempt = {
    id: makeId('listening'),
    drillId: drill.id,
    answer,
    correct: result.isCorrect,
    minutes: Math.max(1, Math.round((Date.now() - (listeningStartedAt || Date.now())) / 60000)),
    rating,
    date: todayISO(),
    createdAt: new Date().toISOString()
  };
  state.listeningAttempts.push(attempt);
  listeningDrillId = null;
  listeningStartedAt = null;
  dictationChecked = false;
  dictationResult = null;
  dictationAnswer = '';
  const undo = () => {
    state.listeningAttempts = state.listeningAttempts.filter((item) => item.id !== attempt.id);
    persist();
    render();
    showToast('已撤销这次听写记录');
  };
  finishMutation(`听写已保存 · ${result.isCorrect ? '逐词一致' : `吻合 ${result.accuracy}%`}`, {
    actionLabel: '撤销',
    onAction: undo
  });
}

function handleSpeakingSubmit(form) {
  if (speakingPhase !== 'done') return formFailure(form, '先完成一次计时作答，再保存口试记录。');
  const data = new FormData(form);
  const rating = Number(data.get('rating') || 0);
  const notes = String(data.get('notes') || '').trim().slice(0, 10000);
  if (!Number.isInteger(rating) || rating < 1 || rating > 5) return formFailure(form, '请选择 1—5 的自评分。', 'rating');
  const prompt = currentSpeakingPrompt();
  const take = {
    id: makeId('speaking'),
    promptId: prompt.id,
    durationSec: Math.max(1, speakingDurationSec),
    prepSec: speakingPrepUsed,
    notes,
    rating,
    date: todayISO(),
    createdAt: new Date().toISOString()
  };
  state.speakingTakes.push(take);
  const duration = take.durationSec;
  disposeSpeakingRuntime();
  const undo = () => {
    state.speakingTakes = state.speakingTakes.filter((item) => item.id !== take.id);
    persist();
    render();
    showToast('已撤销这次口试记录');
  };
  finishMutation(`口试已保存 · ${formatClock(duration)} 作答元数据`, {
    actionLabel: '撤销',
    onAction: undo
  });
}

function handlePracticeAction(action, trigger) {
  if (action === 'practice-mode') {
    setPracticeMode(trigger.dataset.mode);
    return true;
  }
  if (action === 'vocab-reveal') {
    const card = vocabularyCardId ? getVocabularyCard(state, vocabularyCardId) : getNextVocabularyCard(state, new Date());
    if (!card) return true;
    vocabularyCardId = card.id;
    vocabularyRevealed = true;
    render({ scrollMode: 'preserve', focusSelector: '#word-answer' });
    return true;
  }
  if (action === 'rate-vocabulary') {
    rateVocabulary(trigger.dataset.cardId, trigger.dataset.rating);
    return true;
  }
  if (action === 'vocabulary-early') {
    const cards = getVocabularyCards(state);
    const next = cards
      .filter((card) => state.vocabulary.progress[card.id])
      .sort((a, b) => Date.parse(state.vocabulary.progress[a.id]?.dueAt || 0) - Date.parse(state.vocabulary.progress[b.id]?.dueAt || 0))[0];
    if (!next) return true;
    vocabularyCardId = next.id;
    vocabularyRevealed = false;
    render({ scrollMode: 'preserve' });
    return true;
  }
  if (action === 'listen-play' || action === 'listen-slow') {
    playListeningSentence(action === 'listen-slow');
    return true;
  }
  if (action === 'choose-drill') {
    chooseListeningDrill(trigger.dataset.drillId);
    return true;
  }
  if (action === 'next-drill') {
    const index = LISTENING_DRILLS.findIndex((drill) => drill.id === listeningDrillId);
    chooseListeningDrill(LISTENING_DRILLS[(index + 1) % LISTENING_DRILLS.length].id);
    return true;
  }
  if (action === 'choose-speaking-part') {
    const part = Number(trigger.dataset.part);
    if (![1, 2, 3].includes(part) || part === speakingPart) return true;
    disposeSpeakingRuntime();
    speakingPart = part;
    speakingPromptId = SPEAKING_PROMPTS.find((prompt) => prompt.part === part)?.id || speakingPromptId;
    render({ scrollMode: 'preserve' });
    return true;
  }
  if (action === 'choose-speaking-prompt') {
    const prompt = getSpeakingPrompt(trigger.dataset.promptId);
    if (!prompt) return true;
    disposeSpeakingRuntime();
    speakingPart = prompt.part;
    speakingPromptId = prompt.id;
    render({ scrollMode: 'preserve' });
    return true;
  }
  if (action === 'next-speaking-prompt') {
    const next = getNextSpeakingPrompt(speakingPart, speakingPromptId);
    disposeSpeakingRuntime();
    if (next) speakingPromptId = next.id;
    render({ scrollMode: 'preserve' });
    return true;
  }
  if (action === 'speaking-prep') {
    beginSpeakingPrep();
    return true;
  }
  if (action === 'speaking-answer') {
    void startSpeakingAnswer();
    return true;
  }
  if (action === 'speaking-skip-recording') {
    disposeSpeakingRuntime();
    void startSpeakingAnswer({ skipRecording: true });
    return true;
  }
  if (action === 'speaking-stop') {
    void finishSpeakingAnswer();
    return true;
  }
  if (action === 'speaking-reset') {
    disposeSpeakingRuntime();
    render({ scrollMode: 'preserve' });
    return true;
  }
  return false;
}

function setTab(tab, { scrollTop = true, focusSelector = null } = {}) {
  if (!TAB_IDS.has(tab)) return;
  if (activeTab === 'practice' && tab !== 'practice') leavePracticeRuntime();
  activeTab = tab;
  setHash(tab);
  render({ scrollMode: scrollTop ? 'top' : 'preserve', focusSelector });
}

function openWeek(number) {
  openWeekNumber = number;
  setTab('plan');
  requestAnimationFrame(() => {
    const details = document.querySelector(`[data-week-entry="${number}"]`);
    if (!details) return;
    details.open = true;
    details.scrollIntoView({ block: 'center', behavior: 'smooth' });
  });
}

function startTask(taskId) {
  const task = findTask(taskId);
  if (!task) return;
  activeTaskId = activeTaskId === taskId ? null : taskId;
  setTab('today', { scrollTop: Boolean(activeTaskId) });
  if (activeTaskId) {
    requestAnimationFrame(() => {
      const runner = document.getElementById('task-runner');
      if (!runner) return;
      runner.scrollIntoView({ block: 'center', behavior: 'smooth' });
      runner.querySelector('select, input:not([type="hidden"])')?.focus({ preventScroll: true });
    });
  }
}

function clearToast() {
  if (toastTimer) {
    window.clearTimeout(toastTimer);
    toastTimer = null;
  }
  toastAction = null;
  if (toastRoot) toastRoot.innerHTML = '';
}

function showToast(message, { type = 'success', actionLabel = '', onAction = null, duration = 6500 } = {}) {
  ensureOverlays();
  clearToast();
  toastAction = typeof onAction === 'function' ? onAction : null;
  const toast = document.createElement('div');
  toast.className = `toast ${type === 'error' ? 'is-error' : ''}`;
  toast.setAttribute('role', type === 'error' ? 'alert' : 'status');
  toast.innerHTML = `
    <span class="toast-icon">${icon(type === 'error' ? 'warning' : 'check', 16)}</span>
    <span class="toast-copy">${escapeHTML(message)}</span>
    ${toastAction ? `<button class="toast-action" type="button" data-toast-action>${escapeHTML(actionLabel || '撤销')}</button>` : ''}
    <button class="toast-close" type="button" data-toast-close aria-label="关闭提示">${icon('close', 14)}</button>
  `;
  toastRoot.appendChild(toast);
  toastTimer = window.setTimeout(clearToast, duration);
}

function finishMutation(message, toastOptions = {}) {
  const ok = persist();
  render();
  if (ok) {
    showToast(message, toastOptions);
  } else {
    showToast('改动只保留在当前页面，尚未写入本机。请立即导出 JSON。', { type: 'error', duration: 9000 });
  }
  return ok;
}

function markTask(taskId, done) {
  const task = findTask(taskId);
  if (!task) return;
  if (done) {
    state.taskProgress[taskId] = { status: 'done', completedAt: new Date().toISOString() };
  } else {
    delete state.taskProgress[taskId];
  }
  const undo = () => {
    if (done) delete state.taskProgress[taskId];
    else state.taskProgress[taskId] = { status: 'done', completedAt: new Date().toISOString() };
    persist();
    render();
    showToast('任务状态已恢复');
  };
  finishMutation(done ? `已完成：${task.title}` : `已恢复待办：${task.title}`, {
    actionLabel: '撤销',
    onAction: undo
  });
}

function updateScorePreview(form) {
  if (!form) return;
  const scores = {};
  for (const module of SCORE_MODULES) {
    const value = form.elements.namedItem(module)?.value;
    if (value === '') return setPreview(form, null);
    scores[module] = Number(value);
  }
  const overall = calculateOverallBand(scores);
  setPreview(form, overall);
}

function setPreview(form, overall) {
  const valueNode = form.querySelector('.score-preview-value');
  const gapNode = form.querySelector('.score-preview-gap');
  if (valueNode) valueNode.textContent = overall === null ? '—' : formatBand(overall);
  if (gapNode) {
    const target = Number(state.settings.targetBand);
    gapNode.textContent = overall === null
      ? `目标 ${formatBand(target)}`
      : `${overall - target >= 0 ? '+' : ''}${(overall - target).toFixed(1)} vs 目标 ${formatBand(target)}`;
  }
}

function formFailure(form, message, fieldName) {
  showToast(message, { type: 'error', duration: 7500 });
  const field = fieldName ? form.elements.namedItem(fieldName) : null;
  if (field && typeof field.focus === 'function') field.focus();
}

function handleSessionSubmit(form) {
  const data = new FormData(form);
  const sessionId = String(data.get('sessionId') || '');
  const date = String(data.get('date') || '');
  const module = String(data.get('module') || '');
  const activity = String(data.get('activity') || '').trim().slice(0, 240);
  const minutes = Number(data.get('minutes'));
  const outcome = String(data.get('outcome') || '');
  const confidence = Number(data.get('confidence'));
  const notes = String(data.get('notes') || '').trim().slice(0, 10000);
  const taskId = String(data.get('taskId') || '');
  const markDone = data.get('markDone') === 'on';
  const parsedDate = parseISODate(date);

  if (!parsedDate || date > todayISO()) return formFailure(form, '请选择一个不晚于今天的有效训练日期。', 'date');
  if (!SESSION_MODULES.includes(module)) return formFailure(form, '请选择有效的训练模块。', 'module');
  if (!activity) return formFailure(form, '请填写训练内容或题目，否则以后无法复盘。', 'activity');
  if (!Number.isInteger(minutes) || minutes < 1 || minutes > 1440) return formFailure(form, '训练时长应为 1—1440 分钟的整数。', 'minutes');
  if (!OUTCOME_KEYS.includes(outcome)) return formFailure(form, '请选择完成情况。', 'outcome');
  if (!Number.isInteger(confidence) || confidence < 1 || confidence > 5) return formFailure(form, '请选择 1—5 的把握度。', 'confidence');

  const existingIndex = sessionId ? state.sessions.findIndex((session) => session.id === sessionId) : -1;
  const previous = existingIndex >= 0 ? { ...state.sessions[existingIndex] } : null;
  const taskWasDone = taskId ? isTaskDone(state, taskId) : false;
  const nextSession = {
    id: existingIndex >= 0 ? state.sessions[existingIndex].id : makeId('session'),
    date,
    module,
    activity,
    minutes,
    outcome,
    confidence,
    notes,
    taskId: taskId || previous?.taskId || '',
    createdAt: existingIndex >= 0 ? state.sessions[existingIndex].createdAt : new Date().toISOString()
  };

  if (existingIndex >= 0) state.sessions.splice(existingIndex, 1, nextSession);
  else state.sessions.push(nextSession);
  state.sessions.sort((a, b) => a.date.localeCompare(b.date));

  if (taskId && markDone) {
    state.taskProgress[taskId] = { status: 'done', completedAt: new Date().toISOString() };
  }

  editingSessionId = null;
  activeTaskId = null;
  const undo = () => {
    const index = state.sessions.findIndex((session) => session.id === nextSession.id);
    if (index >= 0) {
      if (previous) state.sessions.splice(index, 1, previous);
      else state.sessions.splice(index, 1);
    }
    if (taskId && !taskWasDone) delete state.taskProgress[taskId];
    persist();
    render();
    showToast(previous ? '已恢复到修改前' : '已撤销这条记录');
  };
  const message = existingIndex >= 0
    ? '训练记录已更新'
    : taskId && markDone
      ? '记录已保存，任务已标为完成'
      : '训练记录已保存';
  finishMutation(message, { actionLabel: existingIndex >= 0 ? '恢复' : '撤销', onAction: undo });
}

function handleMockSubmit(form) {
  const data = new FormData(form);
  const mockId = String(data.get('mockId') || '');
  const date = String(data.get('date') || '');
  const notes = String(data.get('notes') || '').trim().slice(0, 10000);
  const parsedDate = parseISODate(date);
  if (!parsedDate || date > todayISO()) return formFailure(form, '请选择一个不晚于今天的有效模考日期。', 'date');

  const scores = {};
  for (const module of SCORE_MODULES) {
    const raw = String(data.get(module) || '');
    const value = Number(raw);
    if (raw === '' || !Number.isFinite(value) || value < 0 || value > 9 || Math.abs(value * 2 - Math.round(value * 2)) > 0.001) {
      return formFailure(form, `请为${MODULE_META[module].label}选择有效的 0—9 分（0.5 递增）。`, module);
    }
    scores[module] = value;
  }

  const existingIndex = mockId ? state.mocks.findIndex((mock) => mock.id === mockId) : -1;
  const previous = existingIndex >= 0 ? { ...state.mocks[existingIndex] } : null;
  const mock = {
    id: existingIndex >= 0 ? state.mocks[existingIndex].id : makeId('mock'),
    date,
    ...scores,
    notes,
    createdAt: existingIndex >= 0 ? state.mocks[existingIndex].createdAt : new Date().toISOString()
  };
  if (existingIndex >= 0) state.mocks.splice(existingIndex, 1, mock);
  else state.mocks.push(mock);
  state.mocks.sort((a, b) => a.date.localeCompare(b.date));

  editingMockId = null;
  const undo = () => {
    const index = state.mocks.findIndex((item) => item.id === mock.id);
    if (index >= 0) {
      if (previous) state.mocks.splice(index, 1, previous);
      else state.mocks.splice(index, 1);
    }
    persist();
    render();
    showToast(previous ? '已恢复到修改前' : '已撤销这次模考');
  };
  finishMutation(existingIndex >= 0 ? '模考记录已更新' : `模考已保存 · 总分 ${formatBand(calculateOverallBand(mock))}`, {
    actionLabel: existingIndex >= 0 ? '恢复' : '撤销',
    onAction: undo
  });
}

function handleSettingsSubmit(form) {
  const data = new FormData(form);
  const planStart = String(data.get('planStart') || '');
  const examDate = String(data.get('examDate') || '');
  const targetBand = Number(data.get('targetBand'));
  const planWeeks = Number(data.get('planWeeks'));
  const weeklyHours = Number(data.get('weeklyHours'));
  const priorities = data.getAll('priorities').map(String).filter((module) => PRIORITY_MODULES.includes(module));

  if (!parseISODate(planStart)) return formFailure(form, '请选择有效的计划起始日。', 'planStart');
  if (examDate && !parseISODate(examDate)) return formFailure(form, '考试日期无效；如未确定请留空。', 'examDate');
  if (examDate && examDate <= planStart) return formFailure(form, '考试日期需要晚于计划起始日。', 'examDate');
  if (!Number.isFinite(targetBand) || targetBand < 0 || targetBand > 9 || Math.abs(targetBand * 2 - Math.round(targetBand * 2)) > 0.001) {
    return formFailure(form, '目标总分需要是 0—9 分之间、0.5 递增的分数。', 'targetBand');
  }
  if (!Number.isInteger(planWeeks) || planWeeks < 4 || planWeeks > 52) return formFailure(form, '计划周数应为 4—52 周的整数。', 'planWeeks');
  if (!Number.isInteger(weeklyHours) || weeklyHours < 4 || weeklyHours > 40) return formFailure(form, '每周投入应为 4—40 小时的整数。', 'weeklyHours');
  if (!priorities.length) return formFailure(form, '至少选择一个计划重心模块。', 'priorities');

  state.settings = normalizeSettings({
    examDate,
    targetBand,
    planStart,
    planWeeks,
    weeklyHours,
    priorities
  });
  plan = buildPlan(state.settings);
  openWeekNumber = getCurrentWeek(plan, new Date())?.number || null;
  activeTaskId = null;
  finishMutation('计划设置已保存，训练记录未受影响');
}

function deleteSession(sessionId) {
  const index = state.sessions.findIndex((session) => session.id === sessionId);
  if (index < 0) return;
  const deleted = { ...state.sessions[index] };
  state.sessions.splice(index, 1);
  if (editingSessionId === sessionId) editingSessionId = null;
  const undo = () => {
    state.sessions.push(deleted);
    state.sessions.sort((a, b) => a.date.localeCompare(b.date));
    persist();
    render();
    showToast('训练记录已恢复');
  };
  finishMutation('训练记录已删除', { actionLabel: '撤销', onAction: undo });
}

function deleteMock(mockId) {
  const index = state.mocks.findIndex((mock) => mock.id === mockId);
  if (index < 0) return;
  const deleted = { ...state.mocks[index] };
  state.mocks.splice(index, 1);
  if (editingMockId === mockId) editingMockId = null;
  const undo = () => {
    state.mocks.push(deleted);
    state.mocks.sort((a, b) => a.date.localeCompare(b.date));
    persist();
    render();
    showToast('模考记录已恢复');
  };
  finishMutation('模考记录已删除', { actionLabel: '撤销', onAction: undo });
}

function exportState() {
  const backup = createBackup(state);
  const content = `${JSON.stringify(backup, null, 2)}\n`;
  const blob = new Blob([content], { type: 'application/json;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `ielts-field-desk-${todayISO()}.json`;
  document.body.appendChild(link);
  link.click();
  link.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 1500);
  markExportedAt();
  render({ scrollMode: 'preserve' });
  showToast(`已导出完整进度 · ${state.sessions.length} 条记录 / ${state.listeningAttempts.length} 次听写 / ${state.speakingTakes.length} 次口试`);
}

function triggerImportPicker() {
  const input = document.createElement('input');
  input.type = 'file';
  input.accept = '.json,application/json';
  input.style.display = 'none';
  document.body.appendChild(input);
  input.addEventListener('change', async () => {
    const file = input.files?.[0];
    if (!file) {
      input.remove();
      return;
    }
    if (file.size > 8 * 1024 * 1024) {
      input.remove();
      pendingImport = {
        name: file.name,
        result: { ok: false, errors: ['文件超过 8 MB，无法作为本训练台的进度备份读取。'], warnings: [], state: null }
      };
      openImportDialog();
      return;
    }
    try {
      const text = await file.text();
      const result = parseBackup(text.replace(/^\uFEFF/, ''));
      pendingImport = { name: file.name, result };
      openImportDialog();
    } catch {
      pendingImport = {
        name: file.name,
        result: { ok: false, errors: ['读取文件失败，请重新选择有效的 JSON 备份。'], warnings: [], state: null }
      };
      openImportDialog();
    } finally {
      input.remove();
    }
  }, { once: true });
  input.click();
}

function wireDialog(dialog, kind) {
  dialogKind = kind;
  dialog.addEventListener('click', (event) => {
    if (event.target === dialog) closeDialog();
  });
  dialog.addEventListener('close', () => {
    if (dialogKind === kind) {
      dialogRoot.innerHTML = '';
      dialogKind = null;
      if (kind === 'import') pendingImport = null;
    }
  });
  dialog.showModal();
}

function openImportDialog() {
  if (!pendingImport) return;
  ensureOverlays();
  if (dialogRoot.querySelector('dialog')) closeDialog();
  const { name, result } = pendingImport;
  if (!result.ok) {
    dialogRoot.innerHTML = `
      <dialog id="import-dialog" aria-labelledby="import-title">
        <div class="dialog-head">
          <div>
            <h2 id="import-title">无法导入这个文件</h2>
            <p>${escapeHTML(name)}</p>
          </div>
          <button class="icon-button" type="button" data-action="close-dialog" aria-label="关闭">${icon('close', 16)}</button>
        </div>
        <div class="dialog-body">
          <div class="error-box">
            <strong>请检查备份来源</strong>
            <ul>${(result.errors || ['未知错误。']).map((error) => `<li>${escapeHTML(error)}</li>`).join('')}</ul>
          </div>
          ${result.warnings?.length ? `<ul class="warning-list">${result.warnings.map((warning) => `<li>${escapeHTML(warning)}</li>`).join('')}</ul>` : ''}
        </div>
        <div class="dialog-actions">
          <button class="btn" type="button" data-action="close-dialog">关闭</button>
          <button class="btn btn-primary" type="button" data-action="import">重新选择文件</button>
        </div>
      </dialog>
    `;
    wireDialog(dialogRoot.querySelector('dialog'), 'import');
    return;
  }

  const incomingSummary = backupSummary(result.state);
  const currentSummary = backupSummary(state);
  const currentIsEmpty = currentSummary.sessions === 0
    && currentSummary.mocks === 0
    && currentSummary.vocabularyReviews === 0
    && currentSummary.customWords === 0
    && currentSummary.listeningAttempts === 0
    && currentSummary.speakingTakes === 0
    && Object.keys(state.taskProgress).length === 0;
  const defaultMode = currentIsEmpty ? 'replace' : 'merge';
  dialogRoot.innerHTML = `
    <dialog id="import-dialog" aria-labelledby="import-title">
      <form data-form="import">
        <div class="dialog-head">
          <div>
            <h2 id="import-title">导入进度备份</h2>
            <p>${escapeHTML(name)} · 导出时间 ${escapeHTML(formatDateTime(result.state.updatedAt))}</p>
          </div>
          <button class="icon-button" type="button" data-action="close-dialog" aria-label="关闭">${icon('close', 16)}</button>
        </div>
        <div class="dialog-body">
          <div class="import-summary" aria-label="备份摘要">
            <div><span>训练记录</span><b>${incomingSummary.sessions}</b></div>
            <div><span>完整模考</span><b>${incomingSummary.mocks}</b></div>
            <div><span>学习日</span><b>${incomingSummary.days}</b></div>
            <div><span>累计分钟</span><b>${incomingSummary.minutes}</b></div>
            <div><span>单词复习</span><b>${incomingSummary.vocabularyReviews}</b></div>
            <div><span>听写记录</span><b>${incomingSummary.listeningAttempts}</b></div>
            <div><span>口试记录</span><b>${incomingSummary.speakingTakes}</b></div>
            <div><span>自建词条</span><b>${incomingSummary.customWords}</b></div>
          </div>
          <p class="import-meta">
            当前本机：${currentSummary.sessions} 条记录、${currentSummary.mocks} 次模考、${currentSummary.vocabularyReviews} 张单词进度、${currentSummary.listeningAttempts} 次听写、${currentSummary.speakingTakes} 次口试。
            ${incomingSummary.firstDate ? `备份覆盖 ${incomingSummary.firstDate}—${incomingSummary.lastDate}。` : '备份中没有训练记录。'}
          </p>
          ${result.warnings.length ? `<div class="error-box"><strong>部分条目被跳过</strong><ul>${result.warnings.slice(0, 8).map((warning) => `<li>${escapeHTML(warning)}</li>`).join('')}</ul>${result.warnings.length > 8 ? `<p>另有 ${result.warnings.length - 8} 条警告。</p>` : ''}</div>` : ''}
          <div class="import-choice" role="radiogroup" aria-label="导入方式">
            <label class="import-mode">
              <input type="radio" name="importMode" value="merge" ${defaultMode === 'merge' ? 'checked' : ''}>
              <span><b>合并记录</b><small>保留当前设置，把备份中不重复的训练、模考与练习加入本机；记录按 ID 去重，单词进度取较新复习。</small></span>
            </label>
            <label class="import-mode">
              <input type="radio" name="importMode" value="replace" ${defaultMode === 'replace' ? 'checked' : ''}>
              <span><b>替换全部进度</b><small>用备份覆盖当前设置、记录、模考、单词进度与练习元数据。适合跨设备首次迁移。</small></span>
            </label>
          </div>
        </div>
        <div class="dialog-actions">
          <button class="btn" type="button" data-action="close-dialog">取消</button>
          <button class="btn btn-primary" type="submit">${currentIsEmpty ? '导入到空白进度' : '导入并应用'}</button>
        </div>
      </form>
    </dialog>
  `;
  wireDialog(dialogRoot.querySelector('dialog'), 'import');
}

function openResetDialog() {
  ensureOverlays();
  if (dialogRoot.querySelector('dialog')) closeDialog();
  dialogRoot.innerHTML = `
    <dialog id="reset-dialog" aria-labelledby="reset-title">
      <form data-form="reset">
        <div class="dialog-head">
          <div>
            <h2 id="reset-title">永久清除本机进度</h2>
            <p>这个动作无法撤销。建议先导出 JSON 备份。</p>
          </div>
          <button class="icon-button" type="button" data-action="close-dialog" aria-label="关闭">${icon('close', 16)}</button>
        </div>
        <div class="dialog-body">
          <div class="error-box">
            <strong>将删除</strong>
            ${state.sessions.length} 条训练记录、${state.mocks.length} 次模考、${Object.keys(state.vocabulary.progress).length} 张单词进度、${state.listeningAttempts.length} 次听写、${state.speakingTakes.length} 次口试，以及全部计划设置与完成勾选。
          </div>
          <div class="field" style="margin-top: 16px">
            <label for="reset-confirm">输入“清除”确认</label>
            <input class="input" id="reset-confirm" name="confirm" type="text" autocomplete="off" spellcheck="false" placeholder="清除" data-reset-input>
            <span class="field-hint">输入完全一致的“清除”后，按钮才会启用。</span>
          </div>
        </div>
        <div class="dialog-actions">
          <button class="btn" type="button" data-action="close-dialog">保留进度</button>
          <button class="btn btn-danger" type="submit" disabled>永久清除</button>
        </div>
      </form>
    </dialog>
  `;
  wireDialog(dialogRoot.querySelector('dialog'), 'reset');
}

function closeDialog() {
  const dialog = dialogRoot?.querySelector('dialog');
  const kind = dialogKind;
  if (dialog?.open) dialog.close();
  if (dialogRoot) dialogRoot.innerHTML = '';
  dialogKind = null;
  if (kind === 'import') pendingImport = null;
}

function handleImportSubmit(form) {
  if (!pendingImport?.result?.ok) {
    closeDialog();
    return;
  }
  const data = new FormData(form);
  const mode = String(data.get('importMode') || 'merge');
  const incoming = pendingImport.result.state;
  leavePracticeRuntime();
  if (mode === 'replace') {
    state = incoming;
  } else {
    state = mergeStates(state, incoming);
  }
  plan = buildPlan(state.settings);
  activeTaskId = null;
  editingSessionId = null;
  editingMockId = null;
  openWeekNumber = getCurrentWeek(plan, new Date())?.number || null;
  const warningSuffix = pendingImport?.result?.warnings?.length ? '，部分无效条目已跳过' : '';
  closeDialog();
  finishMutation(`进度已${mode === 'replace' ? '替换' : '合并'}${warningSuffix}`);
}

function handleResetSubmit(form) {
  const data = new FormData(form);
  if (String(data.get('confirm') || '').trim() !== '清除') {
    formFailure(form, '请输入完全一致的“清除”后再继续。', 'confirm');
    return;
  }
  const result = clearState();
  if (!result.ok) {
    showToast(result.error, { type: 'error', duration: 9000 });
    return;
  }
  leavePracticeRuntime();
  state = createDefaultState();
  plan = buildPlan(state.settings);
  activeTaskId = null;
  openWeekNumber = null;
  editingSessionId = null;
  editingMockId = null;
  recordModule = 'all';
  recordDays = 'all';
  storageWarning = null;
  saveError = null;
  closeDialog();
  const ok = persist();
  render({ scrollMode: 'top' });
  if (ok) showToast('本机进度已清除，训练台已恢复为空白计划');
  else showToast('进度已清除，但新的空白计划未能写入本机。', { type: 'error' });
}

function updateResetButton(input) {
  const form = input.closest('form');
  const button = form?.querySelector('button[type="submit"]');
  if (button) button.disabled = input.value.trim() !== '清除';
}

function handleAppClick(event) {
  const trigger = event.target.closest('[data-action]');
  if (!trigger || trigger.disabled) return;
  if (trigger.tagName === 'INPUT') return;
  const action = trigger.dataset.action;

  if (handlePracticeAction(action, trigger)) return;

  if (action === 'tab') {
    setTab(trigger.dataset.tab);
    return;
  }
  if (action === 'start-task') {
    startTask(trigger.dataset.taskId);
    return;
  }
  if (action === 'close-task') {
    activeTaskId = null;
    render({ scrollMode: 'preserve' });
    return;
  }
  if (action === 'open-week') {
    openWeek(Number(trigger.dataset.week));
    return;
  }
  if (action === 'export') {
    exportState();
    return;
  }
  if (action === 'export-recovery') {
    if (!bootResult.recoveryRaw) return;
    const blob = new Blob([bootResult.recoveryRaw], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `ielts-field-desk-recovery-${todayISO()}.txt`;
    document.body.appendChild(link);
    link.click();
    link.remove();
    window.setTimeout(() => URL.revokeObjectURL(url), 1500);
    showToast('原始恢复副本已请求下载');
    return;
  }
  if (action === 'import') {
    triggerImportPicker();
    return;
  }
  if (action === 'edit-session') {
    editingSessionId = trigger.dataset.sessionId;
    setTab('log', { focusSelector: '#log-activity' });
    return;
  }
  if (action === 'cancel-edit-session') {
    editingSessionId = null;
    render({ scrollMode: 'preserve' });
    return;
  }
  if (action === 'delete-session') {
    deleteSession(trigger.dataset.sessionId);
    return;
  }
  if (action === 'edit-mock') {
    editingMockId = trigger.dataset.mockId;
    setTab('mock', { focusSelector: '#mock-form' });
    return;
  }
  if (action === 'cancel-edit-mock') {
    editingMockId = null;
    render({ scrollMode: 'preserve' });
    return;
  }
  if (action === 'delete-mock') {
    deleteMock(trigger.dataset.mockId);
    return;
  }
  if (action === 'clear-filters') {
    recordModule = 'all';
    recordDays = 'all';
    render({ scrollMode: 'preserve' });
    return;
  }
  if (action === 'reset-open') {
    openResetDialog();
    return;
  }
  if (action === 'focus-mock-form') {
    document.getElementById('mock-form')?.scrollIntoView({ block: 'center', behavior: 'smooth' });
    document.querySelector('#mock-date')?.focus({ preventScroll: true });
  }
}

function handleAppChange(event) {
  const target = event.target;
  if (target.matches('[data-action="toggle-task"]')) {
    markTask(target.dataset.taskId, target.checked);
    return;
  }
  if (target.matches('[data-filter]')) {
    if (target.dataset.filter === 'module') recordModule = target.value;
    if (target.dataset.filter === 'days') recordDays = target.value;
    render({ scrollMode: 'preserve' });
    return;
  }
  if (target.matches('[data-score-input]')) {
    updateScorePreview(target.closest('form'));
  }
}

function handleAppSubmit(event) {
  const form = event.target.closest('form[data-form]');
  if (!form) return;
  const kind = form.dataset.form;
  if (!['session', 'mock', 'settings', 'vocabulary-custom', 'dictation', 'speaking-save'].includes(kind)) return;
  event.preventDefault();
  if (kind === 'session') handleSessionSubmit(form);
  if (kind === 'mock') handleMockSubmit(form);
  if (kind === 'settings') handleSettingsSubmit(form);
  if (kind === 'vocabulary-custom') handleVocabularyCustomSubmit(form);
  if (kind === 'dictation') handleDictationSubmit(form, event.submitter);
  if (kind === 'speaking-save') handleSpeakingSubmit(form);
}

function handleDialogClick(event) {
  if (event.target.closest('[data-action="close-dialog"]')) {
    closeDialog();
    return;
  }
  if (event.target.closest('[data-action="import"]')) {
    closeDialog();
    triggerImportPicker();
  }
}

function handleDialogSubmit(event) {
  const form = event.target.closest('form[data-form]');
  if (!form) return;
  event.preventDefault();
  if (form.dataset.form === 'import') handleImportSubmit(form);
  if (form.dataset.form === 'reset') handleResetSubmit(form);
}

function handleKeydown(event) {
  if ((event.metaKey || event.ctrlKey) && event.key === 'Enter') {
    const form = event.target.closest('form[data-form]');
    if (form) {
      event.preventDefault();
      form.requestSubmit();
    }
  }
}

function handleHashChange() {
  const next = tabFromHash();
  if (next !== activeTab) {
    if (activeTab === 'practice' && next !== 'practice') leavePracticeRuntime();
    activeTab = next;
    render({ scrollMode: 'top' });
  }
}

function registerServiceWorker() {
  if (!('serviceWorker' in navigator)) return;
  if (!['http:', 'https:'].includes(window.location.protocol)) return;
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('./sw.js', { scope: './' }).catch(() => {
      // The app remains fully usable online without an installed service worker.
    });
  });
}

function init() {
  ensureOverlays();
  appRoot.addEventListener('click', handleAppClick);
  appRoot.addEventListener('change', handleAppChange);
  appRoot.addEventListener('submit', handleAppSubmit);
  dialogRoot.addEventListener('click', handleDialogClick);
  dialogRoot.addEventListener('submit', handleDialogSubmit);
  dialogRoot.addEventListener('input', (event) => {
    if (event.target.matches('[data-reset-input]')) updateResetButton(event.target);
  });
  document.addEventListener('keydown', handleKeydown);
  window.addEventListener('hashchange', handleHashChange);
  window.addEventListener('beforeunload', leavePracticeRuntime);
  registerServiceWorker();
  render({ scrollMode: 'top' });
}

init();
