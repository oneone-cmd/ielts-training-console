const DAY_MS = 24 * 60 * 60 * 1000;
const MINUTE_MS = 60 * 1000;

export const VOCAB_RATINGS = {
  again: { label: '忘记', hint: '10 分钟后再见', dueMinutes: 10, easeDelta: -0.2 },
  hard: { label: '模糊', hint: '明天再巩固', baseDays: 1, easeDelta: -0.15 },
  good: { label: '记得', hint: '按间隔推进', baseDays: 2, easeDelta: 0 },
  easy: { label: '熟练', hint: '拉长间隔', baseDays: 4, easeDelta: 0.15 }
};

export const VOCABULARY = [
  { id: 'v01', term: 'mitigate', phonetic: '/ˈmɪtɪɡeɪt/', part: 'v.', meaning: '缓解；减轻负面影响', collocation: 'mitigate the risk of …', example: 'Planting trees along the river can mitigate the risk of flooding downstream.', translation: '沿河植树可以降低下游发生洪水的风险。' },
  { id: 'v02', term: 'exacerbate', phonetic: '/ɪɡˈzæsəbeɪt/', part: 'v.', meaning: '使恶化；加剧', collocation: 'exacerbate an existing problem', example: 'Short-term cuts may exacerbate an already fragile staffing situation.', translation: '短期削减可能让本已脆弱的用工状况进一步恶化。' },
  { id: 'v03', term: 'allocate', phonetic: '/ˈæləkeɪt/', part: 'v.', meaning: '分配；拨给', collocation: 'allocate resources to …', example: 'The council plans to allocate more funding to public transport in outer districts.', translation: '市议会计划向远郊公共交通拨出更多资金。' },
  { id: 'v04', term: 'coherent', phonetic: '/kəʊˈhɪərənt/', part: 'adj.', meaning: '连贯的；有条理的', collocation: 'a coherent argument', example: 'A coherent argument connects each claim to evidence rather than listing opinions.', translation: '连贯的论证会把每个主张与证据连接起来，而不是罗列观点。' },
  { id: 'v05', term: 'ambiguity', phonetic: '/ˌæmbɪˈɡjuːəti/', part: 'n.', meaning: '歧义；模糊之处', collocation: 'remove ambiguity', example: 'The instruction was revised to remove ambiguity about the submission date.', translation: '这条说明经过修改，以消除提交日期上的歧义。' },
  { id: 'v06', term: 'empirical', phonetic: '/ɪmˈpɪrɪkəl/', part: 'adj.', meaning: '以观察或实验为依据的', collocation: 'empirical evidence', example: 'The claim sounds reasonable, but there is little empirical evidence to support it.', translation: '这一说法听起来合理，但几乎没有实证证据支持。' },
  { id: 'v07', term: 'plausible', phonetic: '/ˈplɔːzəbəl/', part: 'adj.', meaning: '看似合理的；可信的', collocation: 'a plausible explanation', example: 'A plausible explanation is not necessarily the correct one.', translation: '看似合理的解释不一定就是正确的解释。' },
  { id: 'v08', term: 'negligible', phonetic: '/ˈneɡlɪdʒəbəl/', part: 'adj.', meaning: '微不足道的；可忽略的', collocation: 'a negligible effect', example: 'The difference in cost was negligible once maintenance was included.', translation: '把维护费用算进去后，成本差异就微不足道了。' },
  { id: 'v09', term: 'deteriorate', phonetic: '/dɪˈtɪəriəreɪt/', part: 'v.', meaning: '恶化；退化', collocation: 'conditions deteriorate', example: 'Air quality may deteriorate rapidly when traffic returns after a holiday.', translation: '假期后交通恢复时，空气质量可能会迅速恶化。' },
  { id: 'v10', term: 'substantial', phonetic: '/səbˈstænʃəl/', part: 'adj.', meaning: '可观的；大量的', collocation: 'a substantial increase', example: 'The programme produced a substantial increase in cycling among young commuters.', translation: '该项目使年轻通勤者中的骑行人数显著增加。' },
  { id: 'v11', term: 'compelling', phonetic: '/kəmˈpelɪŋ/', part: 'adj.', meaning: '有说服力的；引人注目的', collocation: 'compelling evidence', example: 'The report offers compelling evidence that early support reduces dropout rates.', translation: '该报告提供了有说服力的证据，表明早期支持能降低辍学率。' },
  { id: 'v12', term: 'consensus', phonetic: '/kənˈsensəs/', part: 'n.', meaning: '共识；一致意见', collocation: 'reach a consensus', example: 'There is broad consensus that the current system needs reform.', translation: '人们普遍认为现行制度需要改革。' },
  { id: 'v13', term: 'controversy', phonetic: '/ˈkɒntrəvɜːsi/', part: 'n.', meaning: '争议；争论', collocation: 'spark controversy', example: 'The proposal sparked controversy because it changed access to the park.', translation: '该提案引发了争议，因为它改变了进入公园的方式。' },
  { id: 'v14', term: 'criterion', phonetic: '/kraɪˈtɪəriən/', part: 'n.', meaning: '标准；准则（复数 criteria）', collocation: 'meet the criteria', example: 'Cost was only one criterion used when comparing the two designs.', translation: '比较两种设计时，成本只是所用标准之一。' },
  { id: 'v15', term: 'derive', phonetic: '/dɪˈraɪv/', part: 'v.', meaning: '获得；源自', collocation: 'derive from …', example: 'Many local remedies derive from plants that grow in the surrounding forest.', translation: '许多当地疗法源自周边森林中生长的植物。' },
  { id: 'v16', term: 'discrepancy', phonetic: '/dɪsˈkrepənsi/', part: 'n.', meaning: '差异；不一致', collocation: 'a discrepancy between …', example: 'The researchers investigated the discrepancy between reported and recorded income.', translation: '研究人员调查了申报收入与记录收入之间的差异。' },
  { id: 'v17', term: 'facilitate', phonetic: '/fəˈsɪlɪteɪt/', part: 'v.', meaning: '促进；使便利', collocation: 'facilitate access to …', example: 'Clear signs can facilitate access to public services for new residents.', translation: '清楚的标识可以帮助新居民更方便地获得公共服务。' },
  { id: 'v18', term: 'fluctuate', phonetic: '/ˈflʌktʃueɪt/', part: 'v.', meaning: '波动；起伏', collocation: 'prices fluctuate', example: 'Demand for seasonal labour tends to fluctuate throughout the year.', translation: '季节性劳动力的需求全年往往起伏不定。' },
  { id: 'v19', term: 'inherent', phonetic: '/ɪnˈhɪərənt/', part: 'adj.', meaning: '内在的；固有的', collocation: 'an inherent limitation', example: 'Every model has an inherent limitation, no matter how detailed it is.', translation: '无论模型多么细致，都有其固有的局限。' },
  { id: 'v20', term: 'intervention', phonetic: '/ˌɪntəˈvenʃən/', part: 'n.', meaning: '干预；介入措施', collocation: 'early intervention', example: 'Early intervention is often cheaper than treating a problem after it develops.', translation: '早期干预往往比问题形成后再处理更便宜。' },
  { id: 'v21', term: 'justify', phonetic: '/ˈdʒʌstɪfaɪ/', part: 'v.', meaning: '证明……合理；为……辩护', collocation: 'justify the cost', example: 'The city must justify the cost of the new stadium to local taxpayers.', translation: '市政府必须向当地纳税人证明新体育场的成本是合理的。' },
  { id: 'v22', term: 'legitimate', phonetic: '/lɪˈdʒɪtɪmət/', part: 'adj.', meaning: '合理的；合法的', collocation: 'a legitimate concern', example: 'Residents raised legitimate concerns about noise late at night.', translation: '居民对深夜噪音提出了合理的担忧。' },
  { id: 'v23', term: 'marginal', phonetic: '/ˈmɑːdʒɪnəl/', part: 'adj.', meaning: '微小的；边缘的', collocation: 'a marginal improvement', example: 'The second campaign produced only a marginal improvement in attendance.', translation: '第二场活动只让参与率略有提高。' },
  { id: 'v24', term: 'notion', phonetic: '/ˈnəʊʃən/', part: 'n.', meaning: '观念；概念', collocation: 'challenge the notion that …', example: 'The study challenges the notion that longer working hours always raise output.', translation: '这项研究挑战了“工作时间越长产出越高”的观念。' },
  { id: 'v25', term: 'obsolete', phonetic: '/ˈɒbsəliːt/', part: 'adj.', meaning: '过时的；淘汰的', collocation: 'become obsolete', example: 'Some skills become obsolete while others become more valuable.', translation: '有些技能会被淘汰，而另一些技能则变得更有价值。' },
  { id: 'v26', term: 'pervasive', phonetic: '/pəˈveɪsɪv/', part: 'adj.', meaning: '普遍存在的；无处不在的', collocation: 'a pervasive influence', example: 'Advertising has a pervasive influence on how young people view success.', translation: '广告对年轻人看待成功的方式有普遍影响。' },
  { id: 'v27', term: 'preliminary', phonetic: '/prɪˈlɪmɪnəri/', part: 'adj.', meaning: '初步的；预备的', collocation: 'preliminary findings', example: 'The preliminary findings suggest a link, but more data are needed.', translation: '初步发现提示存在关联，但仍需更多数据。' },
  { id: 'v28', term: 'prevalent', phonetic: '/ˈprevələnt/', part: 'adj.', meaning: '普遍的；常见的', collocation: 'increasingly prevalent', example: 'Remote work is increasingly prevalent in industries that rely on digital tools.', translation: '在依赖数字工具的行业中，远程办公越来越普遍。' },
  { id: 'v29', term: 'prohibit', phonetic: '/prəˈhɪbɪt/', part: 'v.', meaning: '禁止', collocation: 'prohibit somebody from doing …', example: 'The regulations prohibit companies from disposing of waste in the river.', translation: '这些法规禁止公司向河中倾倒废物。' },
  { id: 'v30', term: 'reinforce', phonetic: '/ˌriːɪnˈfɔːs/', part: 'v.', meaning: '强化；加固', collocation: 'reinforce a belief', example: 'Repeated exposure to one viewpoint can reinforce existing assumptions.', translation: '反复接触单一观点会强化既有假设。' },
  { id: 'v31', term: 'resilient', phonetic: '/rɪˈzɪliənt/', part: 'adj.', meaning: '有韧性的；能恢复的', collocation: 'a resilient community', example: 'A resilient community can recover quickly after an economic shock.', translation: '有韧性的社区能在经济冲击后迅速恢复。' },
  { id: 'v32', term: 'retain', phonetic: '/rɪˈteɪn/', part: 'v.', meaning: '保留；留住', collocation: 'retain skilled staff', example: 'Flexible hours can help employers retain skilled staff.', translation: '弹性工时可以帮助雇主留住熟练员工。' },
  { id: 'v33', term: 'scrutiny', phonetic: '/ˈskruːtəni/', part: 'n.', meaning: '仔细审查；监督', collocation: 'under public scrutiny', example: 'The decision came under close scrutiny after the costs were published.', translation: '成本公布后，这项决定受到了严密审查。' },
  { id: 'v34', term: 'sustain', phonetic: '/səˈsteɪn/', part: 'v.', meaning: '维持；支撑', collocation: 'sustain growth', example: 'The business struggled to sustain growth after its main market shrank.', translation: '主要市场萎缩后，这家企业难以维持增长。' },
  { id: 'v35', term: 'underlying', phonetic: '/ˌʌndəˈlaɪɪŋ/', part: 'adj.', meaning: '根本的；潜在的', collocation: 'the underlying cause', example: 'Better transport may address the symptom rather than the underlying cause.', translation: '改善交通可能只解决了表面问题，而没有触及根本原因。' },
  { id: 'v36', term: 'viable', phonetic: '/ˈvaɪəbəl/', part: 'adj.', meaning: '可行的；能生存的', collocation: 'a viable alternative', example: 'Solar power has become a viable alternative for many rural households.', translation: '太阳能已成为许多农村家庭可行的替代能源。' },
  { id: 'v37', term: 'widespread', phonetic: '/ˈwaɪdspred/', part: 'adj.', meaning: '广泛的；普遍的', collocation: 'widespread support', example: 'The policy enjoys widespread support but remains difficult to fund.', translation: '该政策获得广泛支持，但资金仍然难以落实。' },
  { id: 'v38', term: 'threshold', phonetic: '/ˈθreʃhəʊld/', part: 'n.', meaning: '门槛；临界值', collocation: 'cross the threshold', example: 'Once income crosses a certain threshold, the subsidy is gradually reduced.', translation: '收入一旦超过某个门槛，补贴就会逐步减少。' },
  { id: 'v39', term: 'undermine', phonetic: '/ˌʌndəˈmaɪn/', part: 'v.', meaning: '削弱；破坏', collocation: 'undermine confidence', example: 'Inconsistent rules can undermine confidence in the planning system.', translation: '规则反复无常会削弱人们对规划制度的信心。' },
  { id: 'v40', term: 'unprecedented', phonetic: '/ʌnˈpresɪdentɪd/', part: 'adj.', meaning: '史无前例的', collocation: 'an unprecedented level of …', example: 'The city recorded an unprecedented level of demand for social housing.', translation: '该市对社会住房的需求达到了史无前例的水平。' },
  { id: 'v41', term: 'account for', phonetic: '/əˈkaʊnt fɔː/', part: 'phr.', meaning: '解释；占（比例）', collocation: 'account for a large share', example: 'Transport accounts for a large share of household carbon emissions.', translation: '交通占家庭碳排放的很大一部分。' },
  { id: 'v42', term: 'bring about', phonetic: '/brɪŋ əˈbaʊt/', part: 'phr.', meaning: '带来；导致', collocation: 'bring about change', example: 'Lasting change is usually brought about by several policies working together.', translation: '持久的改变通常由多项政策共同作用带来。' },
  { id: 'v43', term: 'carry out', phonetic: '/ˈkæri aʊt/', part: 'phr.', meaning: '实施；执行', collocation: 'carry out a survey', example: 'The team carried out a survey of households in three districts.', translation: '团队在三个区开展了家庭调查。' },
  { id: 'v44', term: 'give rise to', phonetic: '/ɡɪv raɪz tuː/', part: 'phr.', meaning: '引起；导致', collocation: 'give rise to debate', example: 'The findings gave rise to debate about how the data had been collected.', translation: '这些发现引发了关于数据如何收集的争论。' },
  { id: 'v45', term: 'in light of', phonetic: '/ɪn laɪt əv/', part: 'phr.', meaning: '鉴于；根据', collocation: 'in light of recent evidence', example: 'In light of recent evidence, the committee revised its original recommendation.', translation: '鉴于近期证据，委员会修改了最初的建议。' },
  { id: 'v46', term: 'on the grounds that', phonetic: '/ɒn ðə ɡraʊndz ðæt/', part: 'phr.', meaning: '以……为理由', collocation: 'reject a proposal on the grounds that …', example: 'The plan was rejected on the grounds that it would increase congestion.', translation: '该方案因会增加拥堵而被否决。' },
  { id: 'v47', term: 'stem from', phonetic: '/stem frəm/', part: 'phr.', meaning: '源于；由……造成', collocation: 'problems stem from …', example: 'Many of the region’s water shortages stem from inefficient irrigation.', translation: '该地区许多缺水问题源于灌溉效率低下。' },
  { id: 'v48', term: 'weigh up', phonetic: '/weɪ ʌp/', part: 'phr.', meaning: '权衡；仔细比较', collocation: 'weigh up the costs and benefits', example: 'Policymakers must weigh up the costs and benefits before changing the tax.', translation: '决策者在修改税率前必须权衡成本与收益。' }
];

export const LISTENING_DRILLS = [
  { id: 'l01', focus: '时间与地点', section: 'S1', sentence: 'The orientation session will begin in the main hall at half past nine.' },
  { id: 'l02', focus: '日期与拼写', section: 'S1', sentence: 'Please submit your application to the student services office by Friday the twelfth of March.' },
  { id: 'l03', focus: '开放时间', section: 'S1', sentence: 'The laboratory closes at six thirty on weekdays and at four on Saturdays.' },
  { id: 'l04', focus: '条件与截止期限', section: 'S2', sentence: 'Students who need an extension must speak to their tutor before the deadline.' },
  { id: 'l05', focus: '价格与数字', section: 'S1', sentence: 'The museum has reduced its ticket price by five pounds for full-time students.' },
  { id: 'l06', focus: '数量与地点', section: 'S2', sentence: 'The research team collected samples from twelve sites across the region.' },
  { id: 'l07', focus: '转折与限定', section: 'S3', sentence: 'Although the initial results looked promising, the sample was too small to be conclusive.' },
  { id: 'l08', focus: '观点与政策', section: 'S4', sentence: 'The lecturer argues that public transport should be treated as essential infrastructure.' },
  { id: 'l09', focus: '调查与态度', section: 'S3', sentence: 'The survey suggests that most residents would support a ban on single-use plastics.' },
  { id: 'l10', focus: '因果与城市变化', section: 'S4', sentence: 'Rising rents have forced many small businesses to relocate outside the city centre.' },
  { id: 'l11', focus: '实验与防错', section: 'S3', sentence: 'The experiment was repeated three times to reduce the risk of measurement error.' },
  { id: 'l12', focus: '比较与区分', section: 'S4', sentence: 'Unlike previous studies, this report distinguishes between cause and correlation.' },
  { id: 'l13', focus: '延迟决定', section: 'S2', sentence: 'The committee postponed its decision until the environmental impact assessment was complete.' },
  { id: 'l14', focus: '能力要求', section: 'S2', sentence: 'Applicants are expected to demonstrate both independent thinking and effective teamwork.' },
  { id: 'l15', focus: '目的与对比', section: 'S4', sentence: 'The new policy aims to encourage recycling rather than simply increase fines.' },
  { id: 'l16', focus: '趋势预测', section: 'S4', sentence: 'By the end of the decade, demand for renewable energy is expected to double.' },
  { id: 'l17', focus: '假设与挑战', section: 'S4', sentence: 'The author challenges the assumption that economic growth always improves living standards.' },
  { id: 'l18', focus: '研究过程', section: 'S3', sentence: 'Participants were asked to record their daily travel time over a period of four weeks.' },
  { id: 'l19', focus: '馆藏与年代', section: 'S2', sentence: 'The library’s digital archive contains newspapers dating back to the nineteenth century.' },
  { id: 'l20', focus: '城市问题', section: 'S3', sentence: 'A lack of affordable housing remains one of the city’s most urgent problems.' }
];

export const SPEAKING_PROMPTS = [
  {
    id: 'p1-01', part: 1, label: 'Part 1', title: 'Study habits',
    prompt: 'How do you usually organise your study time?',
    bullets: ['What helps you stay focused?', 'Has your routine changed recently?', 'What would you like to improve?'],
    prepSec: 15, speakSec: 45, targets: ['直接回答，再补一个具体细节', '用一次时态变化展示自然度', '避免连续使用 very / good']
  },
  {
    id: 'p1-02', part: 1, label: 'Part 1', title: 'Technology',
    prompt: 'Do you use your phone for studying?',
    bullets: ['Which tools do you use?', 'Does it ever distract you?', 'Could you study without it?'],
    prepSec: 15, speakSec: 45, targets: ['先给清楚立场', '具体说明一个使用场景', '用对比句解释利与弊']
  },
  {
    id: 'p1-03', part: 1, label: 'Part 1', title: 'Hometown',
    prompt: 'What is the most interesting part of your hometown?',
    bullets: ['What is it like?', 'Who goes there?', 'Would you take a visitor there?'],
    prepSec: 15, speakSec: 45, targets: ['用一个具体地点代替泛泛而谈', '加入空间或感官细节', '结尾回应问题本身']
  },
  {
    id: 'p1-04', part: 1, label: 'Part 1', title: 'Free time',
    prompt: 'How do you prefer to spend your free time?',
    bullets: ['Alone or with other people?', 'Indoor or outdoor?', 'Why does it help you?'],
    prepSec: 15, speakSec: 45, targets: ['确定一个主要偏好', '解释原因而不是只列举活动', '控制停顿，保持自然节奏']
  },
  {
    id: 'p2-01', part: 2, label: 'Part 2', title: 'A skill to learn',
    prompt: 'Describe a skill you would like to learn.',
    bullets: ['What the skill is', 'How you would learn it', 'How long you think it would take', 'Explain why this skill matters to you'],
    prepSec: 60, speakSec: 120, targets: ['一分钟提纲只写关键词', '按“是什么—怎么学—为什么”展开', '最后 20 秒回到个人意义']
  },
  {
    id: 'p2-02', part: 2, label: 'Part 2', title: 'A difficult problem',
    prompt: 'Describe a time when you had to solve a difficult problem.',
    bullets: ['What the problem was', 'Why it was difficult', 'What you did', 'Explain what you learned from it'],
    prepSec: 60, speakSec: 120, targets: ['用时间线固定故事结构', '至少写两个动作动词', '结果与反思不要混在一起']
  },
  {
    id: 'p2-03', part: 2, label: 'Part 2', title: 'A person who shaped your thinking',
    prompt: 'Describe a person who has influenced the way you think.',
    bullets: ['Who the person is', 'How you know them', 'What they taught you', 'Explain why the influence has lasted'],
    prepSec: 60, speakSec: 120, targets: ['用一件具体往事支撑影响', '区分人物特征与你的变化', '避免空泛的赞美词堆叠']
  },
  {
    id: 'p2-04', part: 2, label: 'Part 2', title: 'A place to concentrate',
    prompt: 'Describe a place where you can concentrate well.',
    bullets: ['Where it is', 'What it looks like', 'What you do there', 'Explain why it helps you focus'],
    prepSec: 60, speakSec: 120, targets: ['用空间移动组织描述', '加入声音、光线或秩序细节', '把环境与注意力联系起来']
  },
  {
    id: 'p3-01', part: 3, label: 'Part 3', title: 'Skills and credentials',
    prompt: 'Do formal qualifications matter less than practical skills today?',
    bullets: ['How do employers judge ability?', 'When are qualifications still essential?', 'Will this balance change in the future?'],
    prepSec: 20, speakSec: 75, targets: ['给出有条件的观点', '用 on the one hand / however 推进', '用具体职业例子限定范围']
  },
  {
    id: 'p3-02', part: 3, label: 'Part 3', title: 'Technology and attention',
    prompt: 'Has technology made people less able to concentrate?',
    bullets: ['What has changed?', 'Is the effect the same for everyone?', 'What could be done about it?'],
    prepSec: 20, speakSec: 75, targets: ['避免把所有问题归因于技术', '讨论人群或场景差异', '结论与前面的证据一致']
  },
  {
    id: 'p3-03', part: 3, label: 'Part 3', title: 'Cities and housing',
    prompt: 'What should cities do to make housing more affordable?',
    bullets: ['Which groups need help most?', 'What are the trade-offs?', 'Who should pay for the solution?'],
    prepSec: 20, speakSec: 75, targets: ['区分短期与长期措施', '明确权衡，不只列政策', '用 may / could 表达政策不确定性']
  },
  {
    id: 'p3-04', part: 3, label: 'Part 3', title: 'Environment and responsibility',
    prompt: 'Should individuals or governments bear more responsibility for environmental damage?',
    bullets: ['Which actions matter most?', 'What limits individual choice?', 'How should responsibility be shared?'],
    prepSec: 20, speakSec: 75, targets: ['避免二元站队', '说明制度如何影响个人选择', '用因果链连接责任与结果']
  }
];

function clamp(value, minimum, maximum) {
  return Math.min(maximum, Math.max(minimum, value));
}

function asDate(value) {
  const date = value instanceof Date ? value : new Date(value);
  return Number.isNaN(date.getTime()) ? new Date() : date;
}

function dateKey(value) {
  const date = asDate(value);
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

function cleanText(value, limit = 240) {
  return typeof value === 'string' ? value.trim().slice(0, limit) : '';
}

export function getVocabularyCards(state) {
  const custom = Array.isArray(state?.vocabulary?.customWords) ? state.vocabulary.customWords : [];
  const seen = new Set(VOCABULARY.map((card) => card.id));
  const customCards = custom.map((card) => {
    if (!card || typeof card !== 'object' || seen.has(card.id)) return null;
    const term = cleanText(card.term, 80);
    if (!term) return null;
    seen.add(card.id);
    return {
      id: cleanText(card.id, 160),
      term,
      phonetic: cleanText(card.phonetic, 100),
      part: cleanText(card.part, 20) || 'word',
      meaning: cleanText(card.meaning, 240),
      collocation: cleanText(card.collocation, 200),
      example: cleanText(card.example, 500),
      translation: cleanText(card.translation, 500),
      custom: true
    };
  }).filter(Boolean);
  return [...VOCABULARY, ...customCards];
}

export function getVocabularyCard(state, cardId) {
  return getVocabularyCards(state).find((card) => card.id === cardId) || null;
}

export function reviewVocabularyCard(current, cardId, rating, now = new Date()) {
  const reviewedAt = asDate(now);
  const ratingMeta = VOCAB_RATINGS[rating] || VOCAB_RATINGS.good;
  const previous = current && typeof current === 'object' ? current : {};
  const previousInterval = Math.max(0, Number(previous.intervalDays) || 0);
  const previousEase = clamp(Number(previous.ease) || 2.3, 1.3, 2.8);
  const previousReps = Math.max(0, Number(previous.reps) || 0);
  const previousLapses = Math.max(0, Number(previous.lapses) || 0);
  let intervalDays;
  let dueAt;

  if (rating === 'again') {
    intervalDays = 0;
    dueAt = reviewedAt.getTime() + ratingMeta.dueMinutes * MINUTE_MS;
  } else if (rating === 'hard') {
    intervalDays = previousInterval ? Math.max(1, Math.round(previousInterval * 1.5)) : 1;
  } else if (rating === 'easy') {
    intervalDays = previousInterval ? Math.max(4, Math.round(previousInterval * previousEase * 1.4)) : 4;
  } else {
    intervalDays = previousInterval ? Math.max(2, Math.round(previousInterval * previousEase)) : 2;
  }

  if (dueAt === undefined) dueAt = reviewedAt.getTime() + intervalDays * DAY_MS;

  return {
    ...previous,
    cardId: cleanText(cardId, 160),
    reps: rating === 'again' ? 0 : Math.min(previousReps + 1, 1000),
    intervalDays: clamp(intervalDays, 0, 365),
    ease: Number(clamp(previousEase + ratingMeta.easeDelta, 1.3, 2.8).toFixed(2)),
    dueAt: new Date(dueAt).toISOString(),
    lastReviewedAt: reviewedAt.toISOString(),
    lastRating: VOCAB_RATINGS[rating] ? rating : 'good',
    lapses: rating === 'again' ? previousLapses + 1 : previousLapses
  };
}

export function getVocabularyQueue(state, now = new Date()) {
  const checkpoint = asDate(now);
  const progress = state?.vocabulary?.progress && typeof state.vocabulary.progress === 'object'
    ? state.vocabulary.progress
    : {};
  const due = [];
  const fresh = [];
  for (const card of getVocabularyCards(state)) {
    const entry = progress[card.id];
    if (!entry) {
      fresh.push(card);
      continue;
    }
    const dueTime = Date.parse(entry.dueAt);
    if (!Number.isFinite(dueTime) || dueTime <= checkpoint.getTime()) due.push({ card, dueAt: dueTime || 0 });
  }
  due.sort((a, b) => a.dueAt - b.dueAt);
  return [...due.map((item) => item.card), ...fresh];
}

export function getNextVocabularyCard(state, now = new Date()) {
  return getVocabularyQueue(state, now)[0] || null;
}

export function getVocabularyStats(state, now = new Date()) {
  const checkpoint = asDate(now);
  const today = dateKey(checkpoint);
  const cards = getVocabularyCards(state);
  const knownIds = new Set(cards.map((card) => card.id));
  const progress = state?.vocabulary?.progress && typeof state.vocabulary.progress === 'object'
    ? state.vocabulary.progress
    : {};
  let due = 0;
  let reviewedToday = 0;
  let mature = 0;
  let nextDueAt = null;
  for (const card of cards) {
    const entry = progress[card.id];
    if (!entry) continue;
    const dueTime = Date.parse(entry.dueAt);
    if (!Number.isFinite(dueTime) || dueTime <= checkpoint.getTime()) due += 1;
    if (entry.lastReviewedAt && dateKey(entry.lastReviewedAt) === today) reviewedToday += 1;
    if ((Number(entry.intervalDays) || 0) >= 7) mature += 1;
    if (Number.isFinite(dueTime) && dueTime > checkpoint.getTime() && (nextDueAt === null || dueTime < nextDueAt)) {
      nextDueAt = dueTime;
    }
  }
  const reviewed = Object.keys(progress).filter((id) => knownIds.has(id)).length;
  return {
    total: cards.length,
    reviewed,
    fresh: cards.length - reviewed,
    due,
    reviewedToday,
    mature,
    nextDueAt: nextDueAt === null ? null : new Date(nextDueAt).toISOString()
  };
}

export function normalizeDictation(value) {
  return String(value ?? '')
    .normalize('NFKD')
    .replace(/\p{M}/gu, '')
    .toLowerCase()
    .replace(/[’‘]/g, "'")
    .replace(/[‐‑‒–—―]/g, ' ')
    .replace(/&/g, ' and ')
    .replace(/[^a-z0-9'\s]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function alignTokens(expected, actual) {
  const rows = expected.length + 1;
  const columns = actual.length + 1;
  const table = Array.from({ length: rows }, () => new Uint16Array(columns));
  for (let i = 1; i < rows; i += 1) {
    for (let j = 1; j < columns; j += 1) {
      table[i][j] = expected[i - 1] === actual[j - 1]
        ? table[i - 1][j - 1] + 1
        : Math.max(table[i - 1][j], table[i][j - 1]);
    }
  }
  const expectedMatched = new Array(expected.length).fill(false);
  const actualMatched = new Array(actual.length).fill(false);
  let i = expected.length;
  let j = actual.length;
  while (i > 0 && j > 0) {
    if (expected[i - 1] === actual[j - 1]) {
      expectedMatched[i - 1] = true;
      actualMatched[j - 1] = true;
      i -= 1;
      j -= 1;
    } else if (table[i - 1][j] >= table[i][j - 1]) {
      i -= 1;
    } else {
      j -= 1;
    }
  }
  return {
    matched: table[expected.length][actual.length],
    missing: expected.filter((_, index) => !expectedMatched[index]),
    extra: actual.filter((_, index) => !actualMatched[index])
  };
}

export function compareDictation(expected, actual) {
  const normalizedExpected = normalizeDictation(expected);
  const normalizedActual = normalizeDictation(actual);
  const expectedTokens = normalizedExpected ? normalizedExpected.split(' ') : [];
  const actualTokens = normalizedActual ? normalizedActual.split(' ') : [];
  const alignment = alignTokens(expectedTokens, actualTokens);
  const denominator = expectedTokens.length + actualTokens.length;
  return {
    normalizedExpected,
    normalizedActual,
    isCorrect: Boolean(normalizedExpected) && normalizedExpected === normalizedActual,
    accuracy: denominator ? Math.round((alignment.matched * 2 / denominator) * 100) : 100,
    matched: alignment.matched,
    missing: alignment.missing,
    extra: alignment.extra
  };
}

export function getListeningStats(state, today = dateKey(new Date())) {
  const attempts = Array.isArray(state?.listeningAttempts) ? state.listeningAttempts : [];
  const correct = attempts.filter((attempt) => attempt.correct).length;
  return {
    total: attempts.length,
    correct,
    accuracy: attempts.length ? Math.round((correct / attempts.length) * 100) : null,
    today: attempts.filter((attempt) => attempt.date === today).length,
    todayCorrect: attempts.filter((attempt) => attempt.date === today && attempt.correct).length
  };
}

export function getNextListeningDrill(state, now = new Date()) {
  const attempts = Array.isArray(state?.listeningAttempts) ? state.listeningAttempts : [];
  const latest = new Map();
  for (const attempt of attempts) {
    const time = Date.parse(attempt.createdAt || '') || 0;
    if (!latest.has(attempt.drillId) || latest.get(attempt.drillId) < time) latest.set(attempt.drillId, time);
  }
  return [...LISTENING_DRILLS].sort((a, b) => {
    const aTime = latest.get(a.id) || 0;
    const bTime = latest.get(b.id) || 0;
    if (aTime !== bTime) return aTime - bTime;
    return LISTENING_DRILLS.indexOf(a) - LISTENING_DRILLS.indexOf(b);
  })[0] || null;
}

export function getSpeakingPrompt(promptId) {
  return SPEAKING_PROMPTS.find((prompt) => prompt.id === promptId) || null;
}

export function getNextSpeakingPrompt(part, currentId = '') {
  const prompts = SPEAKING_PROMPTS.filter((prompt) => prompt.part === Number(part));
  if (!prompts.length) return null;
  const currentIndex = prompts.findIndex((prompt) => prompt.id === currentId);
  return prompts[(currentIndex + 1) % prompts.length] || prompts[0];
}

export function getSpeakingStats(state, today = dateKey(new Date())) {
  const takes = Array.isArray(state?.speakingTakes) ? state.speakingTakes : [];
  return {
    total: takes.length,
    today: takes.filter((take) => take.date === today).length,
    seconds: takes.reduce((sum, take) => sum + Math.max(0, Number(take.durationSec) || 0), 0),
    recorded: takes.filter((take) => Number(take.durationSec) > 0).length
  };
}

export function getPracticeStats(state, now = new Date()) {
  const vocab = getVocabularyStats(state, now);
  const listening = getListeningStats(state, dateKey(now));
  const speaking = getSpeakingStats(state, dateKey(now));
  return {
    vocab,
    listening,
    speaking,
    todayActions: vocab.reviewedToday + listening.today + speaking.today
  };
}

export function formatClock(totalSeconds) {
  const seconds = Math.max(0, Math.round(Number(totalSeconds) || 0));
  return `${String(Math.floor(seconds / 60)).padStart(2, '0')}:${String(seconds % 60).padStart(2, '0')}`;
}
