export const APP_ID = 'ielts-field-desk';
export const SCHEMA_VERSION = 1;
export const STORAGE_KEY = 'ielts-field-desk:v1';

export const MODULE_META = {
  listening: { label: '听力', short: 'L', english: 'Listening' },
  speaking: { label: '口语', short: 'S', english: 'Speaking' },
  reading: { label: '阅读', short: 'R', english: 'Reading' },
  writing: { label: '写作', short: 'W', english: 'Writing' },
  review: { label: '复盘', short: 'V', english: 'Review' }
};

export const SCORE_MODULES = ['listening', 'speaking', 'reading', 'writing'];
export const SESSION_MODULES = [...SCORE_MODULES, 'review'];
export const OUTCOMES = {
  completed: '完成',
  partial: '部分完成',
  struggled: '遇到困难'
};
export const OUTCOME_KEYS = Object.keys(OUTCOMES);
export const PRIORITY_MODULES = ['listening', 'speaking', 'reading', 'writing'];

export const PLAN_PHASES = [
  { key: 'foundation', short: '01 / 地基', label: '建立可测基线' },
  { key: 'precision', short: '02 / 提分', label: '压缩错误类型' },
  { key: 'simulation', short: '03 / 仿真', label: '把练习变成考试' },
  { key: 'taper', short: '04 / 收口', label: '稳定输出与恢复' }
];

export const WEEK_THEMES = [
  { focus: '建立基线', listening: 'S1 / S2 表单填空', speaking: 'Part 1 高频题连续作答', reading: 'T/F/NG 定位证据', writing: 'Task 2 立场与四段结构', evaluation: '完整模考 #1 + 四项归档' },
  { focus: '干扰项识别', listening: 'S3 学术对话干扰项', speaking: 'Part 2 人物题故事线', reading: 'Matching Headings 段落主旨', writing: 'Task 1 趋势图概述', evaluation: '听力拼写 + 口语卡顿回听' },
  { focus: '空间与结构', listening: 'S2 地图与方位', speaking: 'Part 2 地点题空间线', reading: 'Summary Completion 同义替换', writing: 'Task 2 因果论证', evaluation: '地图题专项 + 录音复盘' },
  { focus: '第一次全真', listening: 'S4 讲座结构', speaking: 'Part 3 观点展开', reading: 'Passage 2 时间分配', writing: 'Task 2 让步段', evaluation: '完整模考 #1 + 四项归档' },
  { focus: '细节精确度', listening: '数字、日期与专有名词', speaking: '发音：重音与节奏', reading: 'Y/N/NG 与 T/F/NG 混合', writing: 'Task 1 对比图', evaluation: '精听复述 + 口语重录' },
  { focus: '节奏与证据', listening: '多选题节奏', speaking: 'Part 2 事件题时间线', reading: 'Matching Information', writing: 'Task 2 例证具体化', evaluation: 'Section 3 / 4 联听' },
  { focus: '同义替换', listening: '填空题词性预测', speaking: 'Part 3 比较与评价', reading: 'List of Headings 干扰', writing: 'Task 2 词汇精确度', evaluation: '同义替换词库 + 跟读' },
  { focus: '第二次全真', listening: '口音与连读', speaking: 'Part 2 物品题细节', reading: 'Passage 3 结构阅读', writing: 'Task 1 流程图与地图', evaluation: '完整模考 #2 + 成绩差距' },
  { focus: '时间压力', listening: 'Section 1–4 连做', speaking: 'Part 1 → 3 连贯节奏', reading: '三篇连做与放弃策略', writing: 'Task 2 45 分钟完整稿', evaluation: '时间压力模拟' },
  { focus: '预判与取舍', listening: '错误选项预判', speaking: 'Part 2 一分钟提纲', reading: '判断题证据链', writing: 'Task 1 二十分钟成稿', evaluation: '双科联考：听 + 说' },
  { focus: '第三次全真', listening: '同义替换追踪', speaking: 'Part 3 抽象话题例证', reading: '段落匹配速度', writing: 'Task 2 反方观点回应', evaluation: '完整模考 #3 + 弱项排序' },
  { focus: '稳定输出', listening: 'Section 4 笔记法', speaking: 'Part 2 题库串联', reading: 'Passage 2 精读限时', writing: 'Task 1 数据选择', evaluation: '口语三题连录 + 听力回滚' },
  { focus: '第四次全真', listening: '考场节奏与检查', speaking: 'Part 2 高频题抽签', reading: '三篇六十分钟全真', writing: 'Task 2 高频题限时', evaluation: '完整模考 #4' },
  { focus: '错误收口', listening: '拼写与单复数收口', speaking: '发音与语调收口', reading: '错题模式统计', writing: 'Task 1 / 2 各一篇精修', evaluation: '只看错题，不刷新题' },
  { focus: '最后一次全真', listening: '整套听力两次', speaking: '完整口试模拟', reading: '整套阅读两次', writing: '完整写作两次', evaluation: '全真模考 #5 + 恢复' },
  { focus: '考前收口', listening: '轻量精听与题感', speaking: '口试流程演练', reading: '错题证据复盘', writing: '结构清单与开头结尾', evaluation: '只做熟题，保证睡眠' }
];

const TASK_CHECKLISTS = {
  listening: ['盲听并标记漏听点', '核对同义替换', '写下 3 个错因'],
  speaking: ['45 秒列提纲', '计时录音', '回听并重录一句'],
  reading: ['限时完成', '标注证据句', '统计错误类型'],
  writing: ['10 分钟列结构', '限时成稿', '对照任务回应修改'],
  review: ['按考试顺序完成', '记录四项分数', '写下下一次修正动作']
};

const TASK_PROMPTS = {
  listening: '先盲听，再逐句核对漏听词与同义替换；把注意力断点写进训练证据。',
  speaking: '按考试节奏录音，回听时只抓两个问题：卡顿在哪里，哪句话可以更直接。',
  reading: '限时完成，每道错题都标注原文证据句；不要用“粗心”解释错误。',
  writing: '先列结构再成稿，最后只做一轮针对任务回应的修改，不重写全文。',
  review: '证据优先于刷题量。完成后记录四项分数、情绪与最需要修正的一处。'
};

const clamp = (value, min, max) => Math.min(max, Math.max(min, value));

export function parseISODate(value) {
  if (typeof value !== 'string') return null;
  const match = /^(\d{4})-(\d{2})-(\d{2})/.exec(value);
  if (!match) return null;
  const [, year, month, day] = match;
  const date = new Date(Number(year), Number(month) - 1, Number(day), 12, 0, 0, 0);
  if (date.getFullYear() !== Number(year) || date.getMonth() !== Number(month) - 1 || date.getDate() !== Number(day)) return null;
  return date;
}

export function toLocalDate(value = new Date()) {
  if (value instanceof Date && !Number.isNaN(value.getTime())) {
    return new Date(value.getFullYear(), value.getMonth(), value.getDate(), 12, 0, 0, 0);
  }
  return parseISODate(String(value));
}

export function formatISODate(value = new Date()) {
  const date = toLocalDate(value);
  if (!date) return '';
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export function addDays(value, amount) {
  const date = toLocalDate(value);
  if (!date) return null;
  date.setDate(date.getDate() + amount);
  return date;
}

export function dateDiffDays(from, to) {
  const start = toLocalDate(from);
  const end = toLocalDate(to);
  if (!start || !end) return null;
  return Math.round((end.getTime() - start.getTime()) / 86400000);
}

export function formatMonthDay(value) {
  const date = toLocalDate(value);
  if (!date) return '—';
  return `${date.getMonth() + 1} 月 ${date.getDate()} 日`;
}

export function formatShortDate(value) {
  const date = toLocalDate(value);
  if (!date) return '—';
  return `${String(date.getMonth() + 1).padStart(2, '0')}.${String(date.getDate()).padStart(2, '0')}`;
}

export function formatWeekday(value) {
  const date = toLocalDate(value);
  if (!date) return '—';
  return new Intl.DateTimeFormat('zh-CN', { weekday: 'short' }).format(date);
}

export function formatDuration(minutes) {
  const safe = Math.max(0, Math.round(Number(minutes) || 0));
  if (safe < 60) return `${safe} 分钟`;
  const hours = Math.floor(safe / 60);
  const rest = safe % 60;
  return rest ? `${hours} 小时 ${rest} 分` : `${hours} 小时`;
}

export function formatBand(value) {
  const number = Number(value);
  return Number.isFinite(number) ? number.toFixed(1) : '—';
}

export function defaultSettings(now = new Date()) {
  return {
    examDate: '',
    targetBand: 8,
    planStart: formatISODate(now),
    planWeeks: 16,
    weeklyHours: 12,
    priorities: ['listening', 'speaking']
  };
}

export function createDefaultState(now = new Date()) {
  const timestamp = new Date().toISOString();
  return {
    app: APP_ID,
    schemaVersion: SCHEMA_VERSION,
    createdAt: timestamp,
    updatedAt: timestamp,
    settings: defaultSettings(now),
    sessions: [],
    mocks: [],
    taskProgress: {}
  };
}

export function normalizeSettings(raw = {}, now = new Date()) {
  const source = raw && typeof raw === 'object' ? raw : {};
  const fallback = defaultSettings(now);
  const target = Number(source.targetBand);
  const planWeeks = Number(source.planWeeks);
  const weeklyHours = Number(source.weeklyHours);
  const priorities = Array.isArray(source.priorities)
    ? source.priorities.filter((module) => PRIORITY_MODULES.includes(module))
    : fallback.priorities;
  return {
    examDate: parseISODate(source.examDate) ? formatISODate(source.examDate) : '',
    targetBand: Number.isFinite(target) && target >= 0 && target <= 9 && Math.abs(target * 2 - Math.round(target * 2)) < 0.001 ? target : fallback.targetBand,
    planStart: parseISODate(source.planStart) ? formatISODate(source.planStart) : fallback.planStart,
    planWeeks: Number.isFinite(planWeeks) ? clamp(Math.round(planWeeks), 4, 52) : fallback.planWeeks,
    weeklyHours: Number.isFinite(weeklyHours) ? clamp(Math.round(weeklyHours), 4, 40) : fallback.weeklyHours,
    priorities: priorities.length ? [...new Set(priorities)] : fallback.priorities
  };
}

function phaseForWeek(index, totalWeeks) {
  const width = Math.ceil(totalWeeks / 4);
  return PLAN_PHASES[clamp(Math.floor(index / width), 0, 3)];
}

function taskFor(weekIndex, theme, phase, settings, dayOffset, module, title, minutes) {
  const taskDate = addDays(settings.planStart, weekIndex * 7 + dayOffset);
  const weekLabel = String(weekIndex + 1).padStart(2, '0');
  const kind = module === 'review' ? 'evaluation' : module;
  return {
    id: `w${weekLabel}-d${dayOffset + 1}-${kind}`,
    weekIndex,
    weekNumber: weekIndex + 1,
    phaseKey: phase.key,
    phaseLabel: phase.short,
    scheduledDate: formatISODate(taskDate),
    dayOffset,
    module,
    title,
    prompt: TASK_PROMPTS[module],
    checklist: [...TASK_CHECKLISTS[module]],
    minutes,
    priority: settings.priorities.includes(module)
  };
}

export function buildPlan(settings) {
  const normalized = normalizeSettings(settings);
  const weeklyMinutes = normalized.weeklyHours * 60;
  const perTask = Math.max(30, Math.round(weeklyMinutes / 6 / 5) * 5);
  return Array.from({ length: normalized.planWeeks }, (_, index) => {
    const theme = WEEK_THEMES[index % WEEK_THEMES.length];
    const phase = phaseForWeek(index, normalized.planWeeks);
    const weekStart = addDays(normalized.planStart, index * 7);
    const weekEnd = addDays(weekStart, 6);
    const alternateModule = index % 2 === 0 ? 'listening' : 'speaking';
    const alternateTitle = alternateModule === 'listening'
      ? `Listening · ${theme.listening} · 复述`
      : `Speaking · ${theme.speaking} · 重录`;
    const tasks = [
      taskFor(index, theme, phase, normalized, 0, 'listening', `Listening · ${theme.listening}`, perTask),
      taskFor(index, theme, phase, normalized, 1, 'speaking', `Speaking · ${theme.speaking}`, perTask),
      taskFor(index, theme, phase, normalized, 2, 'reading', `Reading · ${theme.reading}`, perTask),
      taskFor(index, theme, phase, normalized, 3, alternateModule, alternateTitle, perTask),
      taskFor(index, theme, phase, normalized, 4, 'writing', `Writing · ${theme.writing}`, perTask),
      taskFor(index, theme, phase, normalized, 5, 'review', `Review · ${theme.evaluation}`, perTask)
    ];
    return {
      index,
      number: index + 1,
      startDate: formatISODate(weekStart),
      endDate: formatISODate(weekEnd),
      focus: theme.focus,
      phase,
      tasks
    };
  });
}

export function getCurrentWeek(plan, now = new Date()) {
  if (!plan.length) return null;
  const today = formatISODate(now);
  const diff = dateDiffDays(plan[0].startDate, today);
  const index = clamp(Math.floor((diff ?? 0) / 7), 0, plan.length - 1);
  return plan[index];
}

export function isTaskDone(state, taskId) {
  const progress = state.taskProgress?.[taskId];
  return progress?.status === 'done';
}

export function getFocusTasks(state, plan, now = new Date()) {
  const currentWeek = getCurrentWeek(plan, now);
  if (!currentWeek) return [];
  const today = formatISODate(now);
  const incomplete = (week) => week.tasks.filter((task) => task.scheduledDate >= currentWeek.startDate && !isTaskDone(state, task.id));
  const current = incomplete(currentWeek);
  const todays = current.filter((task) => task.scheduledDate === today);
  const upcoming = current.filter((task) => task.scheduledDate > today);
  const overdue = current.filter((task) => task.scheduledDate < today);
  const nextWeek = plan[currentWeek.index + 1];
  const following = nextWeek ? nextWeek.tasks.filter((task) => !isTaskDone(state, task.id)) : [];
  return [...todays, ...overdue, ...upcoming, ...following].slice(0, 3).map((task, index) => ({
    ...task,
    displayStatus: task.scheduledDate === today ? 'today' : task.scheduledDate < today ? 'overdue' : index === 0 ? 'next' : 'later'
  }));
}

export function calculateOverallBand(scores) {
  const values = SCORE_MODULES.map((module) => Number(scores?.[module]));
  if (values.some((value) => !Number.isFinite(value) || value < 0 || value > 9)) return null;
  return Math.round((values.reduce((sum, value) => sum + value, 0) / 4) * 2) / 2;
}

export function getExamCountdown(settings, now = new Date()) {
  if (!settings?.examDate) return null;
  return dateDiffDays(now, settings.examDate);
}

export function calculateStreak(sessions, now = new Date()) {
  const dates = [...new Set(sessions.map((session) => session.date).filter(Boolean))].sort().reverse();
  if (!dates.length) return 0;
  const dateSet = new Set(dates);
  const today = formatISODate(now);
  const yesterday = formatISODate(addDays(now, -1));
  let cursor = dateSet.has(today) ? toLocalDate(today) : dateSet.has(yesterday) ? toLocalDate(yesterday) : null;
  if (!cursor) return 0;
  let streak = 0;
  while (cursor && dateSet.has(formatISODate(cursor))) {
    streak += 1;
    cursor = addDays(cursor, -1);
  }
  return streak;
}

export function getRecentDays(sessions, now = new Date(), count = 7) {
  return Array.from({ length: count }, (_, index) => {
    const date = formatISODate(addDays(now, index - (count - 1)));
    const daySessions = sessions.filter((session) => session.date === date);
    return {
      date,
      minutes: daySessions.reduce((sum, session) => sum + session.minutes, 0),
      count: daySessions.length,
      weekday: formatWeekday(date)
    };
  });
}

export function deriveWeakPoints(sessions) {
  const grouped = new Map();
  for (const session of sessions) {
    if (!['struggled', 'partial'].includes(session.outcome) && session.confidence > 2) continue;
    const module = session.module;
    const current = grouped.get(module) || { module, count: 0, activities: new Map(), lastDate: session.date };
    current.count += 1;
    const activity = session.activity.trim().slice(0, 34) || MODULE_META[module]?.label || module;
    current.activities.set(activity, (current.activities.get(activity) || 0) + 1);
    if (session.date > current.lastDate) current.lastDate = session.date;
    grouped.set(module, current);
  }
  return [...grouped.values()]
    .sort((a, b) => b.count - a.count)
    .slice(0, 3)
    .map((group) => {
      const [activity, count] = [...group.activities.entries()].sort((a, b) => b[1] - a[1])[0];
      return { ...group, activity, activityCount: count };
    });
}

export function getStats(state, plan, now = new Date()) {
  const sessions = Array.isArray(state.sessions) ? state.sessions : [];
  const mocks = Array.isArray(state.mocks) ? state.mocks : [];
  const currentWeek = getCurrentWeek(plan, now);
  const weekSessions = currentWeek
    ? sessions.filter((session) => session.date >= currentWeek.startDate && session.date <= currentWeek.endDate)
    : [];
  const weeklyMinutes = weekSessions.reduce((sum, session) => sum + session.minutes, 0);
  const weekTarget = Number(state.settings.weeklyHours) * 60;
  const weekDone = currentWeek ? currentWeek.tasks.filter((task) => isTaskDone(state, task.id)).length : 0;
  const weekTotal = currentWeek?.tasks.length || 0;
  const moduleMinutes = Object.fromEntries(SESSION_MODULES.map((module) => [module, 0]));
  const moduleSessions = Object.fromEntries(SESSION_MODULES.map((module) => [module, 0]));
  for (const session of sessions) {
    moduleMinutes[session.module] = (moduleMinutes[session.module] || 0) + session.minutes;
    moduleSessions[session.module] = (moduleSessions[session.module] || 0) + 1;
  }
  const sortedMocks = [...mocks].sort((a, b) => (a.date === b.date ? String(a.createdAt).localeCompare(String(b.createdAt)) : a.date.localeCompare(b.date)));
  const latestMock = sortedMocks.at(-1) || null;
  const overall = latestMock ? calculateOverallBand(latestMock) : null;
  const previous = sortedMocks.length > 1 ? sortedMocks.at(-2) : null;
  const previousOverall = previous ? calculateOverallBand(previous) : null;
  const target = Number(state.settings.targetBand) || 8;
  const gaps = latestMock
    ? Object.fromEntries(SCORE_MODULES.map((module) => [module, Number(latestMock[module]) - target]))
    : {};
  return {
    totalMinutes: sessions.reduce((sum, session) => sum + session.minutes, 0),
    totalSessions: sessions.length,
    totalMocks: mocks.length,
    studyDays: new Set(sessions.map((session) => session.date)).size,
    weeklyMinutes,
    weekTarget,
    weeklyPercent: weekTarget ? Math.round((weeklyMinutes / weekTarget) * 100) : 0,
    weekDone,
    weekTotal,
    weeklyCompletion: weekTotal ? Math.round((weekDone / weekTotal) * 100) : 0,
    weekSessions: weekSessions.length,
    moduleMinutes,
    moduleSessions,
    streak: calculateStreak(sessions, now),
    recentDays: getRecentDays(sessions, now, 7),
    weakPoints: deriveWeakPoints(sessions),
    latestMock,
    latestOverall: overall,
    previousOverall,
    mockDelta: overall !== null && previousOverall !== null ? overall - previousOverall : null,
    mockGaps: gaps,
    targetBand: target,
    examDays: getExamCountdown(state.settings, now),
    currentWeek: currentWeek?.number || 1
  };
}

export function getRecommendedAction(state, plan, now = new Date()) {
  const focus = getFocusTasks(state, plan, now);
  if (focus.length) {
    const priority = focus.find((task) => state.settings.priorities.includes(task.module)) || focus[0];
    return priority;
  }
  const lastSession = [...state.sessions].sort((a, b) => b.createdAt.localeCompare(a.createdAt))[0];
  return lastSession ? { module: lastSession.module, title: '做一次轻量复盘', prompt: '回看最近一次训练，只记录一个可修正动作。' } : null;
}

export function mergeStates(current, incoming) {
  const sessionsById = new Map(current.sessions.map((session) => [session.id, session]));
  for (const session of incoming.sessions) if (!sessionsById.has(session.id)) sessionsById.set(session.id, session);
  const mocksById = new Map(current.mocks.map((mock) => [mock.id, mock]));
  for (const mock of incoming.mocks) if (!mocksById.has(mock.id)) mocksById.set(mock.id, mock);
  return {
    ...current,
    sessions: [...sessionsById.values()].sort((a, b) => a.date.localeCompare(b.date)),
    mocks: [...mocksById.values()].sort((a, b) => a.date.localeCompare(b.date)),
    taskProgress: {
      ...current.taskProgress,
      ...Object.fromEntries(Object.entries(incoming.taskProgress).filter(([id]) => !current.taskProgress[id]))
    },
    updatedAt: new Date().toISOString()
  };
}

function safeString(value, fallback = '', limit = 10000) {
  return typeof value === 'string' ? value.slice(0, limit) : fallback;
}

function safeNumber(value, fallback = 0) {
  const number = Number(value);
  return Number.isFinite(number) ? number : fallback;
}

function sanitizeSession(raw, warnings, index) {
  if (!raw || typeof raw !== 'object') return null;
  const date = parseISODate(raw.date) ? formatISODate(raw.date) : '';
  const module = SESSION_MODULES.includes(raw.module) ? raw.module : null;
  const minutes = clamp(Math.round(safeNumber(raw.minutes, 0)), 1, 1440);
  if (!date || !module || !minutes) {
    warnings.push(`第 ${index + 1} 条训练记录无效，已跳过。`);
    return null;
  }
  return {
    id: safeString(raw.id, `session-${Date.now()}-${index}`, 160),
    date,
    module,
    activity: safeString(raw.activity, MODULE_META[module]?.label || '训练', 240),
    minutes,
    outcome: OUTCOME_KEYS.includes(raw.outcome) ? raw.outcome : 'completed',
    confidence: clamp(Math.round(safeNumber(raw.confidence, 3)), 1, 5),
    notes: safeString(raw.notes, '', 10000),
    taskId: raw.taskId ? safeString(raw.taskId, '', 160) : '',
    createdAt: raw.createdAt ? safeString(raw.createdAt, new Date().toISOString(), 80) : new Date().toISOString()
  };
}

function sanitizeMock(raw, warnings, index) {
  if (!raw || typeof raw !== 'object') return null;
  const date = parseISODate(raw.date) ? formatISODate(raw.date) : '';
  const scores = {};
  for (const module of SCORE_MODULES) {
    const value = Number(raw[module]);
    if (!Number.isFinite(value) || value < 0 || value > 9 || Math.abs(value * 2 - Math.round(value * 2)) > 0.001) {
      warnings.push(`第 ${index + 1} 次模考缺少有效的 ${MODULE_META[module].label} 分数，已跳过。`);
      return null;
    }
    scores[module] = value;
  }
  if (!date) {
    warnings.push(`第 ${index + 1} 次模考日期无效，已跳过。`);
    return null;
  }
  return {
    id: safeString(raw.id, `mock-${Date.now()}-${index}`, 160),
    date,
    ...scores,
    notes: safeString(raw.notes, '', 10000),
    createdAt: raw.createdAt ? safeString(raw.createdAt, new Date().toISOString(), 80) : new Date().toISOString()
  };
}

export function parseBackup(text) {
  const errors = [];
  const warnings = [];
  let parsed;
  try {
    parsed = JSON.parse(text);
  } catch {
    return { ok: false, errors: ['文件不是有效的 JSON。'], warnings, state: null };
  }
  if (!parsed || typeof parsed !== 'object') {
    return { ok: false, errors: ['备份文件的顶层必须是一个对象。'], warnings, state: null };
  }
  const rooted = parsed.data && typeof parsed.data === 'object' ? parsed.data : parsed;
  if (parsed.app !== APP_ID && rooted.app !== APP_ID) errors.push('这不是 IELTS 训练台的备份文件。');
  if (Number(parsed.schemaVersion ?? rooted.schemaVersion) !== SCHEMA_VERSION) errors.push(`备份版本不兼容：当前只支持 v${SCHEMA_VERSION}。`);
  if (!Array.isArray(rooted.sessions) || !Array.isArray(rooted.mocks)) errors.push('备份缺少 sessions 或 mocks 数组。');
  if (!rooted.settings || typeof rooted.settings !== 'object') errors.push('备份缺少 settings 设置对象。');
  if (errors.length) return { ok: false, errors, warnings, state: null };
  const sessions = rooted.sessions.slice(0, 20000).map((item, index) => sanitizeSession(item, warnings, index)).filter(Boolean);
  const mocks = rooted.mocks.slice(0, 2000).map((item, index) => sanitizeMock(item, warnings, index)).filter(Boolean);
  const taskProgress = {};
  if (rooted.taskProgress && typeof rooted.taskProgress === 'object') {
    for (const [id, value] of Object.entries(rooted.taskProgress)) {
      if (value && typeof value === 'object' && value.status === 'done') {
        taskProgress[id] = { status: 'done', completedAt: safeString(value.completedAt, new Date().toISOString(), 80) };
      }
    }
  }
  const timestamp = new Date().toISOString();
  return {
    ok: true,
    errors: [],
    warnings,
    state: {
      app: APP_ID,
      schemaVersion: SCHEMA_VERSION,
      createdAt: safeString(rooted.createdAt, timestamp, 80),
      updatedAt: timestamp,
      settings: normalizeSettings(rooted.settings),
      sessions,
      mocks,
      taskProgress
    }
  };
}

export function createBackup(state) {
  return {
    app: APP_ID,
    schemaVersion: SCHEMA_VERSION,
    exportedAt: new Date().toISOString(),
    data: {
      createdAt: state.createdAt,
      updatedAt: state.updatedAt,
      settings: state.settings,
      sessions: state.sessions,
      mocks: state.mocks,
      taskProgress: state.taskProgress
    }
  };
}

export function backupSummary(state) {
  const dates = state.sessions.map((session) => session.date).sort();
  return {
    sessions: state.sessions.length,
    mocks: state.mocks.length,
    days: new Set(dates).size,
    minutes: state.sessions.reduce((sum, session) => sum + session.minutes, 0),
    firstDate: dates[0] || null,
    lastDate: dates.at(-1) || null,
    targetBand: state.settings.targetBand,
    planStart: state.settings.planStart,
    planWeeks: state.settings.planWeeks
  };
}
