import {
  APP_ID,
  SCHEMA_VERSION,
  STORAGE_KEY,
  createDefaultState,
  parseBackup
} from './core.js';

const META_KEY = 'ielts-field-desk:meta';
const RECOVERY_KEY = 'ielts-field-desk:corrupt-recovery';

export function isStorageAvailable() {
  try {
    const probe = '__ielts_field_desk_probe__';
    window.localStorage.setItem(probe, '1');
    window.localStorage.removeItem(probe);
    return true;
  } catch {
    return false;
  }
}

export function loadState(now = new Date()) {
  const fallback = createDefaultState(now);
  if (!isStorageAvailable()) {
    return {
      state: fallback,
      source: 'memory',
      warnings: [],
      error: '浏览器阻止了本机存储。本次记录只保留在当前页面，关闭后会丢失。'
    };
  }

  const raw = window.localStorage.getItem(STORAGE_KEY);
  if (!raw) return { state: fallback, source: 'new', warnings: [], error: null };

  const result = parseBackup(raw);
  if (!result.ok || result.state?.app !== APP_ID || result.state?.schemaVersion !== SCHEMA_VERSION) {
    let recoveryAvailable = false;
    try {
      window.localStorage.setItem(RECOVERY_KEY, raw);
      recoveryAvailable = true;
    } catch {
      recoveryAvailable = false;
    }
    return {
      state: fallback,
      source: 'corrupt',
      warnings: result.warnings || [],
      recoveryRaw: recoveryAvailable ? raw : null,
      error: recoveryAvailable
        ? '本机进度无法读取。训练台已用空白进度打开，并保留了一份原始恢复副本；请先下载该副本再继续。'
        : '本机进度无法读取。训练台已用空白进度打开，原数据未被覆盖。'
    };
  }

  return {
    state: result.state,
    source: 'storage',
    warnings: result.warnings || [],
    error: null
  };
}

export function saveState(state) {
  if (!isStorageAvailable()) {
    return { ok: false, error: '浏览器阻止了本机存储，记录尚未保存。请先导出 JSON 备份。' };
  }
  try {
    const payload = {
      ...state,
      app: APP_ID,
      schemaVersion: SCHEMA_VERSION
    };
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(payload));
    window.localStorage.setItem(META_KEY, JSON.stringify({
      lastSavedAt: new Date().toISOString(),
      estimatedBytes: JSON.stringify(payload).length
    }));
    return { ok: true, error: null };
  } catch (error) {
    const quota = error?.name === 'QuotaExceededError' || error?.name === 'NS_ERROR_DOM_QUOTA_REACHED';
    return {
      ok: false,
      error: quota
        ? '本机存储空间已满，最新改动没有写入。请先导出 JSON，再清理浏览器站点数据。'
        : '最新改动没有写入本机存储。请导出 JSON 后再继续。'
    };
  }
}

export function readSaveMeta() {
  try {
    const raw = window.localStorage.getItem(META_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    return parsed && typeof parsed === 'object' ? parsed : null;
  } catch {
    return null;
  }
}

export function markExportedAt() {
  try {
    const current = readSaveMeta() || {};
    window.localStorage.setItem(META_KEY, JSON.stringify({
      ...current,
      lastExportedAt: new Date().toISOString()
    }));
  } catch {
    // Export still works when metadata cannot be written.
  }
}

export function clearState() {
  try {
    window.localStorage.removeItem(STORAGE_KEY);
    window.localStorage.removeItem(META_KEY);
    return { ok: true, error: null };
  } catch {
    return { ok: false, error: '无法清除本机存储。请手动清理这个站点的浏览器数据。' };
  }
}
